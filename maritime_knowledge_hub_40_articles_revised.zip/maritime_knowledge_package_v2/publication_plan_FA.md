# فهرست کامل ۴۰ مقاله دانشنامه حکمرانی و مقررات دریایی

نسخه تجمیعی: ۲۵ اکتبر ۲۰۲۶ | ۲۳ مقاله قبلی + ۱۷ مقاله یکتای فایل تازه | ۱۰ دسته موضوعی

این فهرست مربوط به **محتوای آماده استقرار** است، نه انتشار قطعی روی وب‌سایت اصلی. نشانی‌های زیر مسیرهای پیشنهادی پس از استقرارند.

## مقررات IMO و انطباق — 10 مقاله

- [از الحاق تا نتیجه: چگونه کد III به نقشه راه اجرای تعهدات دریایی تبدیل می‌شود؟](https://aliakbarmarzban.ir/fa/knowledge/iii-code-implementation/) — از بسته قبلی (`C02`)
- [کنوانسیون، کد، قطعنامه و بخشنامه IMO چه تفاوت حقوقی دارند؟](https://aliakbarmarzban.ir/fa/knowledge/imo-legal-instruments/) — از بسته قبلی (`C01`)
- [مسیر تصمیم‌سازی در IMO؛ از پیشنهاد فنی تا تعهد قابل اجرا](https://aliakbarmarzban.ir/fa/knowledge/imo-decision-making/) — از بسته قبلی (`C01`)
- [هوشمندی مقرراتی دریایی؛ نظام هشدار زودهنگام برای مدیران](https://aliakbarmarzban.ir/fa/knowledge/regulatory-intelligence/) — از بسته قبلی (`C01`)
- [آمادگی برای IMSAS؛ شواهدی که اجرای واقعی تعهدات را نشان می‌دهد](https://aliakbarmarzban.ir/fa/knowledge/imsas-audit-preparation/) — از بسته قبلی (`C02`)
- [کنترل دولت صاحب بندر و مسئولیت دولت پرچم؛ دو لایه مکمل ایمنی](https://aliakbarmarzban.ir/fa/knowledge/port-state-control/) — از بسته قبلی (`C02`)
- [چرا الحاق به کنوانسیون دریایی به معنای اجرای موفق آن نیست؟](https://aliakbarmarzban.ir/fa/knowledge/maritime-convention-accession-vs-implementation/) — افزوده‌شده از فایل جدید (`C02`)
- [واگذاری وظایف به سازمان‌های شناخته‌شده؛ مسئولیت دولت کجا باقی می‌ماند؟](https://aliakbarmarzban.ir/fa/knowledge/flag-state-responsibility-recognized-organizations-oversight/) — افزوده‌شده از فایل جدید (`C02`)
- [چگونه مدیران باید اصلاحیه‌های IMO را پیش از لازم‌الاجرا شدن مدیریت کنند؟](https://aliakbarmarzban.ir/fa/knowledge/managing-imo-amendments-before-entry-into-force/) — افزوده‌شده از فایل جدید (`C01`)
- [یافته‌های کنترل دولت بندر چه چیزی درباره ضعف‌های مدیریتی آشکار می‌کنند؟](https://aliakbarmarzban.ir/fa/knowledge/what-psc-findings-reveal-about-management-weaknesses/) — افزوده‌شده از فایل جدید (`C02`)

## حکمرانی بندری و اصلاحات نهادی — 4 مقاله

- [انتخاب مدل حکمرانی بندری؛ از مالکیت دارایی تا پاسخ‌گویی در عملکرد](https://aliakbarmarzban.ir/fa/knowledge/port-governance-models/) — از بسته قبلی (`C03`)
- [داشبورد عملکرد بندر؛ کدام شاخص‌ها واقعاً به تصمیم کمک می‌کنند؟](https://aliakbarmarzban.ir/fa/knowledge/port-kpi-governance/) — از بسته قبلی (`C03`)
- [نظارت بر قراردادهای امتیاز بندری؛ از تعهد سرمایه‌گذاری تا کیفیت خدمت](https://aliakbarmarzban.ir/fa/knowledge/port-concession-oversight/) — از بسته قبلی (`C03`)
- [مذاکره مجدد قرارداد بندری؛ اصلاح ضروری یا نشانه ضعف حکمرانی؟](https://aliakbarmarzban.ir/fa/knowledge/port-concession-renegotiation-governance-risk/) — افزوده‌شده از فایل جدید (`C03`)

## دریانوردان و عامل انسانی — 6 مقاله

- [آمادگی برای بازنگری جامع STCW؛ اصلاح نظام کیفیت پیش از تغییر متن مقررات](https://aliakbarmarzban.ir/fa/knowledge/stcw-review-readiness/) — از بسته قبلی (`C05`)
- [صدور و شناسایی گواهینامه STCW؛ کنترل اصالت، صلاحیت و کیفیت](https://aliakbarmarzban.ir/fa/knowledge/stcw-certification-quality/) — از بسته قبلی (`C05`)
- [MLC 2006 و رفاه دریانوردان؛ از رعایت حداقل‌ها تا حکمرانی عامل انسانی](https://aliakbarmarzban.ir/fa/knowledge/mlc-2006-human-element/) — از بسته قبلی (`C05`)
- [شناسایی گواهینامه دریانوردان؛ چرا یک توافق اداری کافی نیست؟](https://aliakbarmarzban.ir/fa/knowledge/seafarer-certificate-recognition-stcw-regulation-i10/) — افزوده‌شده از فایل جدید (`C05`)
- [نظارت بر مؤسسات آموزش دریایی؛ فراتر از بررسی مدارک و مجوزها](https://aliakbarmarzban.ir/fa/knowledge/oversight-maritime-training-institutions-stcw-quality/) — افزوده‌شده از فایل جدید (`C05`)
- [خستگی دریانوردان؛ چرا مدیریت ایمنی بدون توجه به عامل انسانی کامل نیست؟](https://aliakbarmarzban.ir/fa/knowledge/seafarer-fatigue-safety-management-human-element-stcw-mlc/) — افزوده‌شده از فایل جدید (`C05`)

## سرمایه‌گذاری و PPP — 2 مقاله

- [سرمایه‌گذاری و مشارکت عمومی‌ـ‌خصوصی در بندر؛ آزمون بانک‌پذیری نهادی](https://aliakbarmarzban.ir/fa/knowledge/port-ppp-bankability/) — از بسته قبلی (`E02`)
- [مشارکت عمومی–خصوصی بندری؛ چه زمانی سرمایه‌گذاری به ارزش عمومی تبدیل می‌شود؟](https://aliakbarmarzban.ir/fa/knowledge/port-ppp-concession-public-value-governance/) — افزوده‌شده از فایل جدید (`E02`)

## دیجیتالی‌سازی دریایی — 3 مقاله

- [پنجره واحد دریایی MSW؛ از الزام کنوانسیون FAL تا اجرا در بندر](https://aliakbarmarzban.ir/fa/knowledge/maritime-single-window/) — از بسته قبلی (`E01`)
- [حکمرانی داده و ریسک سایبری در بنادر؛ مسئولیت فراتر از واحد IT](https://aliakbarmarzban.ir/fa/knowledge/maritime-data-governance-cyber/) — از بسته قبلی (`E01`)
- [پنجره واحد دریایی؛ چرا دیجیتالی‌سازی پیش از فناوری به حکمرانی نیاز دارد؟](https://aliakbarmarzban.ir/fa/knowledge/maritime-single-window-governance-digitalization-fal/) — افزوده‌شده از فایل جدید (`E01`)

## قراردادها و مدیریت ریسک — 4 مقاله

- [طراحی مناقصه دریایی؛ از شرح خدمات تا ماتریس تخصیص ریسک](https://aliakbarmarzban.ir/fa/knowledge/maritime-tender-risk/) — از بسته قبلی (`C04`)
- [قرارداد دریایی، یادداشت تفاهم و امتیاز؛ انتخاب ابزار حقوقی مناسب](https://aliakbarmarzban.ir/fa/knowledge/maritime-contract-types/) — از بسته قبلی (`C04`)
- [مناقصه دریایی موفق از کجا آغاز می‌شود؟ از تعریف درست دامنه کار](https://aliakbarmarzban.ir/fa/knowledge/maritime-tender-success-begins-with-scope-of-work/) — افزوده‌شده از فایل جدید (`C04`)
- [تخصیص نامناسب ریسک؛ چگونه قرارداد دریایی به اختلاف تبدیل می‌شود؟](https://aliakbarmarzban.ir/fa/knowledge/inappropriate-contractual-risk-allocation-maritime-disputes/) — افزوده‌شده از فایل جدید (`C04`)

## مذاکرات و همکاری‌های بین‌المللی — 4 مقاله

- [آمادگی هیئت مذاکره دریایی؛ از نقشه منافع تا متن توافق](https://aliakbarmarzban.ir/fa/knowledge/maritime-negotiation-brief/) — از بسته قبلی (`C06`)
- [از تفاهم‌نامه دریایی تا همکاری قابل سنجش؛ چگونه MoU روی کاغذ نماند؟](https://aliakbarmarzban.ir/fa/knowledge/maritime-mou-cooperation/) — از بسته قبلی (`C07`)
- [هیئت مذاکره دریایی موفق پیش از ورود به جلسه چه چیزی آماده می‌کند؟](https://aliakbarmarzban.ir/fa/knowledge/successful-maritime-negotiation-delegation-preparation/) — افزوده‌شده از فایل جدید (`C06`)
- [از امضای تفاهم‌نامه تا اجرای همکاری؛ چرا بسیاری از توافق‌ها به نتیجه نمی‌رسند؟](https://aliakbarmarzban.ir/fa/knowledge/maritime-mou-implementation-gap-governance/) — افزوده‌شده از فایل جدید (`C07`)

## کربن‌زدایی و مقررات اقلیمی — 3 مقاله

- [کربن‌زدایی دریایی در IMO؛ تفکیک راهبرد ۲۰۲۳ از چارچوب خالص صفر](https://aliakbarmarzban.ir/fa/knowledge/imo-decarbonization-status/) — از بسته قبلی (`C08`)
- [EU ETS و FuelEU Maritime؛ ماتریس مواجهه برای شرکت‌های کشتیرانی](https://aliakbarmarzban.ir/fa/knowledge/eu-ets-fueleu-maritime/) — از بسته قبلی (`C08`)
- [کربن‌زدایی کشتیرانی؛ مدیران چگونه در شرایط عدم قطعیت مقرراتی تصمیم بگیرند؟](https://aliakbarmarzban.ir/fa/knowledge/maritime-decarbonization-regulatory-uncertainty-executive-strategy/) — افزوده‌شده از فایل جدید (`C08`)

## کارشناسی مستقل و پیشگیری از اختلاف — 2 مقاله

- [گزارش کارشناسی مستقل در اختلافات دریایی؛ از ادعا تا شواهد قابل بازبینی](https://aliakbarmarzban.ir/fa/knowledge/independent-maritime-expert/) — از بسته قبلی (`E03`)
- [کارشناس مستقل در اختلافات دریایی؛ چگونه تحلیل بی‌طرفانه از تشدید اختلاف جلوگیری می‌کند؟](https://aliakbarmarzban.ir/fa/knowledge/independent-expert-maritime-dispute-prevention-advisory/) — افزوده‌شده از فایل جدید (`E03`)

## آموزش و توسعه شایستگی — 2 مقاله

- [تضمین کیفیت آموزش مدیران دریایی؛ از سیلابس تا شایستگی قابل ارزیابی](https://aliakbarmarzban.ir/fa/knowledge/maritime-training-assurance/) — از بسته قبلی (`E04`)
- [چرا آموزش مدیران دریایی باید به تصمیم واقعی سازمان منتهی شود؟](https://aliakbarmarzban.ir/fa/knowledge/why-maritime-executive-training-must-lead-to-real-decisions/) — افزوده‌شده از فایل جدید (`E04`)

## قاعده جدید قالب مقالات

**در متن نمایشی هر مقاله:** عنوان، لید بدون برچسب «خلاصه در یک جمله»، بدنه تحلیلی، چک‌لیست، پرسش‌های متداول در صورت وجود، پیوند ساده حوزه مرتبط، یادداشت تحریریه و در **آخرین بخش فقط «منابع»** با ارجاعات انگلیسی.

**اطلاعات سئو و فنی** شامل چکیده و نامک انگلیسی در فراداده و فایل CMS نگهداری می‌شوند و به‌صورت تیترهای اضافی داخل مقاله نمایش داده نمی‌شوند.

## فرایند انتشار و جلوگیری از محتوای تکراری

نسخه‌های تکراری نوشته «یافته‌های کنترل دولت بندر...» و «شناسایی گواهینامه دریانوردان...» در فایل جدید، به‌ترتیب به یک مقاله مستقل تبدیل شده‌اند؛ مقاله‌های مشابه قبلی با نامک و زاویه مستقل حفظ شده و از طریق مطالعه بیشتر قابل دسترسی هستند.

پیش از فعال‌سازی تغییرمسیرهای ۳۰۱، وجود همه مقصدهای `/fa/knowledge/{slug}/` و کد موفقیت صفحات را کنترل کنید. دسته‌بندی، برچسب، تصویر، عنوان سئو، توضیح متا، نویسنده و زمان آخرین ویرایش را در CMS نگاشت کنید.

## بررسی حقوقی و ویرایشی

در نمونه‌های حساس مقرراتی، رویه PSC سال ۲۰۲۵ با قطعنامه IMO A.1206(34)، چارچوب ممیزی IMSAS با قطعنامه A.1211(34)، و فرایند بازنگری STCW و وضعیت هنوز نهایی‌نشده IMO Net-Zero Framework از هم تفکیک شده‌اند. پیش از انتشار، بازبینی حقوقی خط‌به‌خط و کنترل زنده تمام لینک‌ها برای هر ۴۰ مقاله پیشنهاد می‌شود.
