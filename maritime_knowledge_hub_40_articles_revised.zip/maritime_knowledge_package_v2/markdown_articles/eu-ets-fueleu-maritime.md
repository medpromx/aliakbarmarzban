---
title: EU ETS و FuelEU Maritime؛ ماتریس مواجهه برای شرکت‌های کشتیرانی
slug: eu-ets-fueleu-maritime
language: fa-IR
dir: rtl
type: knowledge_article
category: کربن‌زدایی و مقررات اقلیمی
summary: دو رژیم اروپایی با منطق متفاوت که بر مسیر سفر، داده انتشار، قرارداد و تصمیم مالی اثر می‌گذارند.
author: علی‌اکبر مرزبان
course_reference: C08
status: editorial-draft
last_editorial_update: '2026-10-25'
original_persian_date: null
canonical_url: https://aliakbarmarzban.ir/fa/knowledge/eu-ets-fueleu-maritime/
old_url: null
related_service: https://aliakbarmarzban.ir/fa/services/
sources:
- title: European Commission — EU ETS Maritime FAQ
  url: https://climate.ec.europa.eu/areas-action/transport-decarbonisation/reducing-emissions-shipping-sector/faq-maritime-transport-eu-emissions-trading-system-ets_en
- title: European Commission — FuelEU Maritime
  url: https://transport.ec.europa.eu/transport-modes/maritime/decarbonising-maritime-transport-fueleu-maritime_en
---

# EU ETS و FuelEU Maritime؛ ماتریس مواجهه برای شرکت‌های کشتیرانی

## دو ابزار با هدف مشترک، سازوکار متفاوت
**EU ETS Maritime** هزینه و تعهد تسلیم سهمیه را به انتشار مشمول مرتبط می‌کند؛ **FuelEU Maritime** بر شدت انتشار گازهای گلخانه‌ای انرژی استفاده‌شده در کشتی تمرکز دارد. این دو باید جداگانه در سیستم تطبیق مقررات و محاسبات قراردادی مدیریت شوند. برای تعیین شمول، نوع کشتی، تناژ، سفر و بندرهای مرتبط اهمیت دارند.

## تقویم اجرای EU ETS
مطابق توضیحات کمیسیون اروپا، شمول کشتیرانی تجاری در ETS از انتشار سال ۲۰۲۴ آغاز شده و تسلیم سهمیه به‌صورت مرحله‌ای انجام می‌شود: برای انتشار سال ۲۰۲۴ سهم ۴۰ درصد، سال ۲۰۲۵ سهم ۷۰ درصد و از انتشار سال ۲۰۲۶ به بعد سهم کامل در چارچوب مقررات مربوط مطرح است. همچنین از سال ۲۰۲۶ گازهایی فراتر از CO₂ در دامنه گزارش مربوط قرار می‌گیرند. این ارقام باید هنگام استفاده عملیاتی با متن قانونی، دامنه شمول و آخرین اطلاعیه رسمی راستی‌آزمایی شوند.

## منطق قراردادی
در اجاره زمانی یا سفر، طرف کنترل‌کننده تصمیم عملیات، سوخت و مسیر الزاماً همان طرف دارای مسئولیت رسمی تطبیق نیست. به همین دلیل نحوه ارائه داده، تخصیص هزینه، اخطار، حسابرسی و تسویه باید در قرارداد روشن شود. نباید بدون توجه به متن خاص قرارداد، هزینه را خودکار به یکی از طرف‌ها نسبت داد.

## ماتریس مواجهه ناوگان
برای هر کشتی یا خدمت، ستون‌های نوع/تناژ، مسیر و بنادر، داده MRV، مسئول گزارش، مسئول هزینه قراردادی، وضعیت FuelEU و رویدادهای تسویه را تکمیل کنید. پیشنهاد می‌شود واحد مقررات، عملیات، مالی و قرارداد هر ماه تغییرات مهم را مرور کنند. این گزارش جایگزین بررسی تخصصی قوانین اتحادیه اروپا نیست.

## چک‌لیست کاربردی
- [ ] نوع کشتی و مسیر مشمول را با قواعد رسمی تطبیق دهید
- [ ] ETS و FuelEU را در دو ردیف مستقل نگه دارید
- [ ] مسئول داده و پرداخت را در قرارداد روشن کنید
- [ ] نسخه مقررات اروپایی را در هر دوره گزارش کنترل کنید

## پرسش‌های متداول
### آیا ETS و FuelEU یک مقرره هستند؟

خیر. سازوکار و مبنای محاسبه آنها متفاوت است و می‌توانند هم‌زمان بر یک عملیات اثر بگذارند.

## حوزه مرتبط
[مشاوره تخصصی تکمیلی](https://aliakbarmarzban.ir/fa/services/)

> یادداشت تحریریه: این مطلب برای آگاهی و تصمیم‌سازی مدیریتی تهیه شده است. اجرای مقررات تابع نسخه معتبر، وضعیت حقوقی کشور و شرایط واقعی پرونده است.

## منابع
- [European Commission — EU ETS Maritime FAQ](https://climate.ec.europa.eu/areas-action/transport-decarbonisation/reducing-emissions-shipping-sector/faq-maritime-transport-eu-emissions-trading-system-ets_en)
- [European Commission — FuelEU Maritime](https://transport.ec.europa.eu/transport-modes/maritime/decarbonising-maritime-transport-fueleu-maritime_en)
