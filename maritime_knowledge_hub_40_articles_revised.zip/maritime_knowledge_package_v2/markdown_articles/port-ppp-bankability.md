---
title: سرمایه‌گذاری و مشارکت عمومی‌ـ‌خصوصی در بندر؛ آزمون بانک‌پذیری نهادی
slug: port-ppp-bankability
language: fa-IR
dir: rtl
type: knowledge_article
category: سرمایه‌گذاری و PPP
summary: پیش از مدل مالی، باید قابلیت اتکای مجوزها، توزیع ریسک و صلاحیت مرجع واگذارکننده را ارزیابی کرد.
author: علی‌اکبر مرزبان
course_reference: E02
status: editorial-draft
last_editorial_update: '2026-10-25'
original_persian_date: null
canonical_url: https://aliakbarmarzban.ir/fa/knowledge/port-ppp-bankability/
old_url: null
related_service: https://aliakbarmarzban.ir/fa/services/
sources:
- title: World Bank — Port Reform Toolkit (3rd Edition)
  url: https://www.worldbank.org/en/topic/transport/publication/port-reform-toolkit
- title: World Bank — Public-Private Partnership Reference and Guidance
  url: https://ppp.worldbank.org/
- title: UNCTAD — Review of Maritime Transport 2025
  url: https://unctad.org/publication/review-maritime-transport-2025
---

# سرمایه‌گذاری و مشارکت عمومی‌ـ‌خصوصی در بندر؛ آزمون بانک‌پذیری نهادی

## چرا یک پروژه با بازده جذاب متوقف می‌شود؟
پروژه بندری ممکن است در مدل مالی توجیه‌پذیر باشد، اما به‌دلیل تعارض اختیارات، ابهام در مالکیت زمین، عدم شفافیت تعرفه یا تغییرات پیش‌بینی‌نشده در مجوزها تأمین مالی نشود. بانک‌پذیری فقط نسبت‌های مالی نیست؛ بخشی از آن به **قابلیت پیش‌بینی نهادی و قراردادی** مربوط می‌شود.

## ارزیابی اولیه پیش از مناقصه
نخست باید مشخص شود کدام نهاد حق واگذاری دارد، زمین و زیرساخت در اختیار چه مرجعی است، مجوزها چگونه صادر می‌شوند و آیا تضمین‌های پیشنهادی با قوانین مالی و بودجه‌ای کشور سازگارند. سپس ریسک تقاضا، ساخت، بهره‌برداری، تغییر قانون، ارز و فورس‌ماژور بین طرف‌ها تقسیم شود. اصل طراحی این است که ریسک به طرفی واگذار شود که **بهترین توان مدیریت یا کنترل آن** را دارد؛ نه صرفاً طرفی که قدرت مذاکره کمتری دارد.

## تفاوت PPP، قرارداد خدمت و خصوصی‌سازی
برچسب PPP برای همه مدل‌های واگذاری مناسب نیست. قرارداد کوتاه‌مدت خدماتی، امتیاز بهره‌برداری بلندمدت و مشارکت در توسعه زیرساخت از منظر سرمایه‌گذاری، مالکیت و مسئولیت دولت تفاوت دارند. انتخاب مدل باید با تحلیل تقاضا، رقابت، مصالح عمومی و ظرفیت نظارت انجام شود.

## یادداشت تصمیم سرمایه‌گذاری
یک یادداشت دوصفحه‌ای تهیه کنید که ساختار حقوقی، نقشه مجوزها، فهرست ریسک‌های غیرقابل واگذاری، پیش‌شرط‌های ورود سرمایه‌گذار و سناریوی شکست را نشان دهد. این یادداشت مکمل مدل مالی و بررسی حقوقی تخصصی است و جایگزین آن‌ها نیست.

## چک‌لیست کاربردی
- [ ] صلاحیت مرجع واگذارکننده و وضعیت دارایی را احراز کنید
- [ ] ریسک تقاضا و تغییر قانون را صریح تخصیص دهید
- [ ] پیش‌شرط‌های تأمین مالی و مجوز را ثبت کنید
- [ ] توان نظارت بلندمدت کارفرما را بسنجید

## پرسش‌های متداول
### آیا PPP به معنی انتقال همه ریسک‌ها به بخش خصوصی است؟

خیر. توزیع ریسک باید متناسب با توان کنترل و ظرفیت پذیرش ریسک هر طرف باشد.

## حوزه مرتبط
[مشاوره تخصصی تکمیلی](https://aliakbarmarzban.ir/fa/services/)

> یادداشت تحریریه: این مطلب برای آگاهی و تصمیم‌سازی مدیریتی تهیه شده است. اجرای مقررات تابع نسخه معتبر، وضعیت حقوقی کشور و شرایط واقعی پرونده است.

## منابع
- [World Bank — Port Reform Toolkit (3rd Edition)](https://www.worldbank.org/en/topic/transport/publication/port-reform-toolkit)
- [World Bank — Public-Private Partnership Reference and Guidance](https://ppp.worldbank.org/)
- [UNCTAD — Review of Maritime Transport 2025](https://unctad.org/publication/review-maritime-transport-2025)
