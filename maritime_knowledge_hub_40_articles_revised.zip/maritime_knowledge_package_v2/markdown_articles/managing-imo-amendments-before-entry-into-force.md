---
title: چگونه مدیران باید اصلاحیه‌های IMO را پیش از لازم‌الاجرا شدن مدیریت کنند؟
slug: managing-imo-amendments-before-entry-into-force
language: fa-IR
dir: rtl
type: knowledge_article
category: مقررات IMO و انطباق
summary: پیگیری اخبار عمومی سازمان بین‌المللی دریانوردی برای تضمین انطباق سازمانی کافی نیست؛ مدیریت کارآمد نیازمند استقرار
  یک فرآیند هوشمندی مقرراتی است که اصلاحیه‌ها را از مرحله مذاکرات مقدماتی تا ارزیابی شمول، تخصیص…
author: علی‌اکبر مرزبان
course_reference: C01
status: editorial-draft
last_editorial_update: '2026-10-25'
original_persian_date: null
canonical_url: https://aliakbarmarzban.ir/fa/knowledge/managing-imo-amendments-before-entry-into-force/
old_url: null
related_service: https://aliakbarmarzban.ir/fa/services/imo-regulation/
sources:
- title: IMO — List of Conventions
  url: https://www.imo.org/en/about/conventions/pages/default.aspx
- title: IMO — FAL Convention and 2022 amendments
  url: https://www.imo.org/en/about/conventions/pages/convention-on-facilitation-of-international-maritime-traffic-%28fal%29.aspx
- title: IMO — Maritime Single Window
  url: https://www.imo.org/en/ourwork/facilitation/pages/maritimesinglewindow-default.aspx
---

# چگونه مدیران باید اصلاحیه‌های IMO را پیش از لازم‌الاجرا شدن مدیریت کنند؟

بسیاری از مراجع دریایی و شرکت‌های کشتیرانی، تحولات مقرراتی را صرفاً پس از تصویب نهایی یا در آستانه فرارسیدن موعد لازم‌الاجرا شدن معاهدات دنبال می‌کنند. این رویکرد واکنشی، ریسک بروز عدم‌انطباق، توقیف شناورها در بازرسی‌های کنترل دولت بندر (PSC) و تحمیل هزینه‌های شتاب‌زده را به شدت افزایش می‌دهد. برای ایجاد انطباق پایدار، مدیران ارشد باید چهار مرحله متمایز را در چرخه اسناد IMO شناسایی کنند:

1. **اسناد مباحثاتی (Discussion Papers):** طرح اولیه ایده‌ها و چالش‌ها در کمیته‌ها بدون تعهد حقوقی؛
2. **تدابیر پیشنهادی (Proposed Measures):** پیش‌نویس متون فنی در کارگروه‌ها و زیرکمیته‌ها؛
3. **اصلاحیه‌های مصوب (Adopted Amendments):** متون تصویب‌شده در کمیته‌ها تحت سازوکار پذیرش ضمنی (Tacit Acceptance) با تاریخ‌های قطعی پذیرش و اجرا؛
4. **الزامات لازم‌الاجرا (In-Force Requirements):** قواعد حقوقی الزام‌آور که مبنای ممیزی، بازرسی و اقدام قانونی هستند.

## روش چهارمرحله‌ای مدیریت تغییر و انطباق پیش‌دستانه

برای گذار از انفعال به پایش سازمان‌یافته، استقرار این الگوی چهارمرحله‌ای ضروری است:

- **۱. رصد فعال تحولات (Regulatory Monitoring):** بررسی منظم دستورکار و گزارش‌های نشست‌های اصلی (MSC, MEPC, FAL, LEG) جهت شناسایی زودهنگام تصمیمات در دست بررسی.
- **۲. ارزیابی دامنه شمول و آثار (Applicability Assessment):** تحلیل موشکافانه اینکه اصلاحیه جدید کدام دسته از شناورها (از نظر سن، نوع و ظرفیت)، بنادر، گواهینامه‌ها یا الزامات تقنینی ملی را هدف قرار می‌دهد.
- **۳. تخصیص شفاف مسئولیت‌ها (Responsibility Assignment):** تعیین واحد سازمانی مسئول، برآورد نیازمندی‌های سرمایه‌ای یا عملیاتی و بازطراحی چک‌لیست‌ها و سیستم‌های داخلی.
- **۴. ردگیری و آمادگی اجرایی (Implementation Tracking):** پایش مداوم پیشرفت اقدامات تا زمان حصول اطمینان کامل پیش از تاریخ سررسید رسمی.

_نمونه کاربردی:_ در الزام تجهیز به «پنجره واحد دریایی» (MSW) ذیل کنوانسیون FAL، سازمان‌هایی که بلافاصله پس از تصویب اصلاحیه در سال ۲۰۲۲ بازطراحی معماری داده‌ها و هماهنگی میان‌نهادی با گمرک را آغاز کردند، در موعد لازم‌الاجرا شدن (اول ژانویه ۲۰۲۴) به انطباق کامل دست یافتند؛ در حالی که غفلت از این پنجره زمانی به ناهماهنگی در تبادل اسناد و اختلال در توقفگاه‌های بندری انجامید.

## نتیجه‌گیری راهبردی

فاصله زمانی میان تصویب یک اصلاحیه تا لازم‌الاجرا شدن آن (که در سازوکار پذیرش ضمنی معمولاً بین ۱۶ تا ۲۴ ماه است)، یک دوره انتظار منفعل نیست؛ بلکه فرصتی راهبردی برای آموزش پرسنل، تطبیق قراردادها و ارتقای ناوگان و بنادر محسوب می‌شود.

## چک‌لیست کاربردی
- [ ] بررسی گزارش نشست‌های MSC، MEPC، FAL و LEG
- [ ] تفکیک پیشنهاد، تصویب، پذیرش و لازم‌الاجرا شدن
- [ ] ارزیابی دامنه شمول اصلاحیه بر ناوگان و فعالیت‌ها
- [ ] ثبت واحد مسئول، منابع و موعد تکمیل هر اقدام

## حوزه مرتبط
[مقررات بین‌المللی دریایی و امور IMO](https://aliakbarmarzban.ir/fa/services/imo-regulation/)

> یادداشت تحریریه: این مطلب برای آگاهی و تصمیم‌سازی مدیریتی تهیه شده است. اجرای مقررات تابع نسخه معتبر، وضعیت حقوقی کشور و شرایط واقعی پرونده است.

## منابع
- [IMO — List of Conventions](https://www.imo.org/en/about/conventions/pages/default.aspx)
- [IMO — FAL Convention and 2022 amendments](https://www.imo.org/en/about/conventions/pages/convention-on-facilitation-of-international-maritime-traffic-%28fal%29.aspx)
- [IMO — Maritime Single Window](https://www.imo.org/en/ourwork/facilitation/pages/maritimesinglewindow-default.aspx)
