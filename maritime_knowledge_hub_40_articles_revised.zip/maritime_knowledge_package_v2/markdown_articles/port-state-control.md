---
title: کنترل دولت صاحب بندر و مسئولیت دولت پرچم؛ دو لایه مکمل ایمنی
slug: port-state-control
language: fa-IR
dir: rtl
type: knowledge_article
category: مقررات IMO و انطباق
summary: تمایز نظارت مستمر دولت پرچم با کنترل موردی دولت بندر و پیامدهای مدیریتی توقیف کشتی.
author: علی‌اکبر مرزبان
course_reference: C02
status: editorial-draft
last_editorial_update: '2026-10-25'
original_persian_date: null
canonical_url: https://aliakbarmarzban.ir/fa/knowledge/port-state-control/
old_url: null
related_service: https://aliakbarmarzban.ir/fa/services/imo-regulation/
sources:
- title: IMO — Port State Control / A.1206(34)
  url: https://www.imo.org/en/ourwork/iiis/pages/port%20state%20control.aspx
- title: UN — United Nations Convention on the Law of the Sea
  url: https://www.un.org/depts/los/convention_agreements/texts/unclos/UNCLOS-TOC.htm
- title: IMO — III Code, Resolution A.1070(28)
  url: https://wwwcdn.imo.org/localresources/en/OurWork/IIIS/Documents/1070.pdf
---

# کنترل دولت صاحب بندر و مسئولیت دولت پرچم؛ دو لایه مکمل ایمنی

## مسئولیت اصلی با کدام دولت است؟
بر اساس حقوق بین‌الملل دریاها، دولت صاحب پرچم وظایف کلیدی کنترل اداری، فنی و اجتماعی بر کشتی‌های تحت پرچم خود دارد. **کنترل دولت صاحب بندر (PSC)** سازوکار تکمیلی بازرسی شناور خارجی در بندر است؛ جایگزین وظیفه نظارت دولت پرچم نیست. هر دو باید بر مبنای اسناد قابل اعمال، حدود صلاحیت و اصول تناسب عمل کنند.

## بازرس چه چیزی را می‌سنجد؟
PSC معمولاً با بررسی اسناد، گواهینامه‌ها و وضعیت عینی کشتی آغاز می‌شود. در صورت وجود قرائن روشن، بازرسی دقیق‌تر ممکن است انجام شود. نقص‌های جدی می‌توانند به اقدامات اصلاحی یا توقیف منجر شوند. اما هر نقص اداری الزاماً معیار توقیف نیست؛ تصمیم باید متناسب با خطر، مستند و مبتنی بر رویه‌های قابل اعمال باشد. مرجع راهنمای رویه‌های PSC، ازجمله قطعنامه جاری **A.1206(34)** (رویه‌های کنترل دولت صاحب بندر، ۲۰۲۵)، برای مدیران حوزه بازرسی اهمیت دارد.

## ریسک نهادی فراتر از یک کشتی
افزایش یافته‌های مشابه در چند کشتی، می‌تواند نشانه ضعف نظارت دولت پرچم، آموزش خدمه، کیفیت ممیزی ISM یا عملکرد سازمان‌های تفویض‌شده باشد. بنابراین داده‌های PSC باید به داشبورد ریسک دولت پرچم بازگردد. نگاه صرفاً پرونده‌ای به هر توقیف، فرصت اصلاح ساختاری را از بین می‌برد.

## تصمیم پیشنهادی
یک چرخه ارتباط بین داده PSC، نظارت پرچم، بازرسی‌های دوره‌ای و اقدام اصلاحی ایجاد کنید. شاخص‌ها را به‌صورت نرخ و روند، با توجه به حجم ناوگان و تغییر ترکیب ریسک تفسیر کنید. برای شکایات ناشی از تأخیر یا توقیف ناموجه نیز سازوکار بررسی روشن پیش‌بینی شود.

## چک‌لیست کاربردی
- [ ] تفاوت مسئولیت اصلی و نظارت تکمیلی را مستند کنید
- [ ] برای توقیف یا رفع توقیف پرونده استدلال نگه دارید
- [ ] یافته‌های تکراری را به اصلاح نظام پرچم متصل کنید
- [ ] روندها را با مخرج آماری مناسب بسنجید

## پرسش‌های متداول
### آیا هر نقص کشتی به توقیف منجر می‌شود؟

خیر. نوع، شدت و اثر نقص بر ایمنی، امنیت یا محیط‌زیست در چارچوب مقررات قابل اعمال اهمیت دارد.

## حوزه مرتبط
[مقررات بین‌المللی دریایی و امور IMO](https://aliakbarmarzban.ir/fa/services/imo-regulation/)

> یادداشت تحریریه: این مطلب برای آگاهی و تصمیم‌سازی مدیریتی تهیه شده است. اجرای مقررات تابع نسخه معتبر، وضعیت حقوقی کشور و شرایط واقعی پرونده است.

## منابع
- [IMO — Port State Control / A.1206(34)](https://www.imo.org/en/ourwork/iiis/pages/port%20state%20control.aspx)
- [UN — United Nations Convention on the Law of the Sea](https://www.un.org/depts/los/convention_agreements/texts/unclos/UNCLOS-TOC.htm)
- [IMO — III Code, Resolution A.1070(28)](https://wwwcdn.imo.org/localresources/en/OurWork/IIIS/Documents/1070.pdf)
