---
title: از تفاهم‌نامه دریایی تا همکاری قابل سنجش؛ چگونه MoU روی کاغذ نماند؟
slug: maritime-mou-cooperation
language: fa-IR
dir: rtl
type: knowledge_article
category: مذاکرات و همکاری‌های بین‌المللی
summary: همکاری بین‌المللی باید به برنامه اقدام، مسئول اجرا، منابع و شاخص دستاورد متصل شود.
author: علی‌اکبر مرزبان
course_reference: C07
status: editorial-draft
last_editorial_update: '2026-10-25'
original_persian_date: null
canonical_url: https://aliakbarmarzban.ir/fa/knowledge/maritime-mou-cooperation/
old_url: null
related_service: https://aliakbarmarzban.ir/fa/services/
sources:
- title: World Bank — Port Reform Toolkit (3rd Edition)
  url: https://www.worldbank.org/en/topic/transport/publication/port-reform-toolkit
- title: United Nations — Treaty Handbook
  url: https://treaties.un.org/pages/Resource.aspx?path=Publication/TH/Page1_en.xml
- title: IMO — Organization Structure
  url: https://www.imo.org/en/about/pages/structure.aspx
---

# از تفاهم‌نامه دریایی تا همکاری قابل سنجش؛ چگونه MoU روی کاغذ نماند؟

## از نمایش همکاری به حل مسئله
تفاهم‌نامه‌ای که تنها بر حسن نیت و تبادل تجربه تأکید می‌کند، لزوماً ارزش اجرایی نمی‌آفریند. آغاز صحیح، تعریف یک نیاز مشخص است: آموزش بازرس، ارتقای فرایند دیجیتال، تبادل تجربه مدیریت بندر یا پژوهش مشترک. سپس شریک بالقوه با معیارهایی مانند تناسب مأموریت، ظرفیت تحویل، تعارض منافع و امکان همکاری پایدار ارزیابی شود.

## چهار لایه طراحی MoU
لایه نخست، **هدف و دامنه** همکاری است. لایه دوم، **حکمرانی اجرا** شامل نقاط تماس و کمیته مشترک است. لایه سوم، **منابع و حفاظت اطلاعات** است؛ باید روشن باشد چه هزینه‌هایی تقبل می‌شود و چگونه محرمانگی رعایت می‌گردد. لایه چهارم، **پیگیری و خاتمه** است: زمان مرور، معیار موفقیت و قواعد پایان همکاری. اگر متن از ابتدا غیرالزام‌آور طراحی شده، باید این مقصود با توجه به قانون حاکم با دقت منعکس شود.

## برنامه شش‌ماهه پیشنهادی
برای یک همکاری آموزشی می‌توان سه مرحله طراحی کرد: ماه اول، نیازسنجی و توافق بر برنامه؛ ماه‌های دوم تا چهارم، اجرای فعالیت پایلوت؛ ماه‌های پنجم و ششم، ارزیابی کیفیت و تصمیم درباره ادامه. این زمان‌بندی صرفاً نمونه مدیریت پروژه است. هر فعالیت باید مالک، بودجه، معیار پذیرش و صورت‌جلسه مستند داشته باشد.

## سنجش دستاورد
شاخص‌هایی مانند تعداد جلسه یا امضای سند به‌تنهایی ارزش‌افزوده را نمی‌سنجند. میزان انتقال دانش، کیفیت خروجی فنی، استمرار ارتباط و انجام اقدامات برنامه‌ریزی‌شده شاخص‌های مناسب‌تری‌اند. گاهی توقف به‌موقع همکاری کم‌اثر نیز نتیجه صحیح حکمرانی است.

## چک‌لیست کاربردی
- [ ] مسئله مشترک و معیار انتخاب شریک را ثبت کنید
- [ ] دامنه و وضعیت حقوقی MoU را روشن کنید
- [ ] برنامه ۶ ماهه را به منابع و مسئول وصل کنید
- [ ] بر نتیجه واقعی، نه تعداد مراسم، گزارش دهید

## پرسش‌های متداول
### آیا برای شروع هر همکاری به MoU نیاز است؟

لزوماً خیر. ابزار همکاری باید با ماهیت فعالیت و قواعد حقوقی مربوط انتخاب شود.

## حوزه مرتبط
[مذاکرات و همکاری‌های بین‌المللی](https://aliakbarmarzban.ir/fa/services/)

> یادداشت تحریریه: این مطلب برای آگاهی و تصمیم‌سازی مدیریتی تهیه شده است. اجرای مقررات تابع نسخه معتبر، وضعیت حقوقی کشور و شرایط واقعی پرونده است.

## منابع
- [World Bank — Port Reform Toolkit (3rd Edition)](https://www.worldbank.org/en/topic/transport/publication/port-reform-toolkit)
- [United Nations — Treaty Handbook](https://treaties.un.org/pages/Resource.aspx?path=Publication/TH/Page1_en.xml)
- [IMO — Organization Structure](https://www.imo.org/en/about/pages/structure.aspx)
