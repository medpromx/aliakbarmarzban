---
title: آمادگی هیئت مذاکره دریایی؛ از نقشه منافع تا متن توافق
slug: maritime-negotiation-brief
language: fa-IR
dir: rtl
type: knowledge_article
category: مذاکرات و همکاری‌های بین‌المللی
summary: کتابچه راهنمای هیئت، حدود اختیار و سازوکار مستندسازی، کیفیت مذاکره‌های دوجانبه و چندجانبه را افزایش می‌دهد.
author: علی‌اکبر مرزبان
course_reference: C06
status: editorial-draft
last_editorial_update: '2026-10-25'
original_persian_date: null
canonical_url: https://aliakbarmarzban.ir/fa/knowledge/maritime-negotiation-brief/
old_url: null
related_service: https://aliakbarmarzban.ir/fa/services/
sources:
- title: IMO — Organization Structure
  url: https://www.imo.org/en/about/pages/structure.aspx
- title: United Nations — Treaty Handbook
  url: https://treaties.un.org/pages/Resource.aspx?path=Publication/TH/Page1_en.xml
- title: UNCTAD — Review of Maritime Transport 2025
  url: https://unctad.org/publication/review-maritime-transport-2025
---

# آمادگی هیئت مذاکره دریایی؛ از نقشه منافع تا متن توافق

## چرا هیئت‌ها در جلسه غافلگیر می‌شوند؟
گاهی اعضای هیئت درباره هدف نهایی توافق دارند اما بر سر **خطوط قرمز، امتیاز قابل واگذاری و اختیار تصویب** هماهنگ نیستند. مذاکره موفق فقط مهارت سخنوری نیست؛ نتیجه آمادگی نهادی، پژوهش مستند و تقسیم نقش است. در مذاکرات دریایی، یک عبارت فنی درباره دامنه شمول، زمان اجرا یا گزارش‌دهی می‌تواند پیامد مالی و حقوقی قابل توجهی داشته باشد.

## کتابچه راهنمای هیئت چیست؟
**Delegation Briefing Book** باید مسئله، اسناد رسمی، منافع طرفین، هدف مطلوب، حداقل نتیجه قابل پذیرش، گزینه جایگزین توافق (BATNA)، نقشه ذی‌نفعان، پیام‌های کلیدی و حدود اختیار اعضا را در بر گیرد. متن پیشنهادیِ بندها و گزینه‌های جایگزین باید پیش از نشست آماده باشد تا هیئت صرفاً به واکنش به پیشنهاد طرف مقابل محدود نشود.

## مدیریت متن مذاکرات
ثبت نسخه‌های متن، کروشه‌ها، پیشنهاددهنده هر تغییر و علت پذیرش یا رد، از ابهام پس از مذاکره جلوگیری می‌کند. بهتر است مسئول حقوقی یا مقرراتی، مسئول ثبت سوابق و سخنگوی هیئت از پیش تعیین شوند. «توافق شفاهی» تا زمانی که در مسیر تصویب داخلی معتبر قرار نگیرد، نباید به‌عنوان تعهد قطعی سازمان گزارش شود.

## پس از جلسه چه می‌شود؟
گزارش پایانی باید موارد توافق، موضوعات باز، تعهدات پیگیری، مسئول و موعد را مشخص کند. اگر حاصل نشست صرفاً تفاهم اولیه است، این وضعیت باید شفاف نوشته شود. شاخص موفقیت مذاکره نه تعداد دیدارها، بلکه پیشرفت موضوعات قابل اجرا و میزان کاهش ابهام است.

## چک‌لیست کاربردی
- [ ] هدف، BATNA و حدود اختیار را پیشاپیش ثبت کنید
- [ ] نسخه متن و تغییرات را مدیریت کنید
- [ ] توافق اولیه را با تعهد قطعی اشتباه نگیرید
- [ ] برنامه پیگیری همراه با مسئول و موعد تهیه کنید

## پرسش‌های متداول
### آیا امضای صورت‌جلسه همیشه تعهد حقوقی قطعی ایجاد می‌کند؟

بستگی به متن، اختیار طرفین، تشریفات و قانون حاکم دارد؛ باید از نظر حقوقی بررسی شود.

## حوزه مرتبط
[مذاکرات و همکاری‌های بین‌المللی](https://aliakbarmarzban.ir/fa/services/)

> یادداشت تحریریه: این مطلب برای آگاهی و تصمیم‌سازی مدیریتی تهیه شده است. اجرای مقررات تابع نسخه معتبر، وضعیت حقوقی کشور و شرایط واقعی پرونده است.

## منابع
- [IMO — Organization Structure](https://www.imo.org/en/about/pages/structure.aspx)
- [United Nations — Treaty Handbook](https://treaties.un.org/pages/Resource.aspx?path=Publication/TH/Page1_en.xml)
- [UNCTAD — Review of Maritime Transport 2025](https://unctad.org/publication/review-maritime-transport-2025)
