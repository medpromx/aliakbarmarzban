---
title: گزارش کارشناسی مستقل در اختلافات دریایی؛ از ادعا تا شواهد قابل بازبینی
slug: independent-maritime-expert
language: fa-IR
dir: rtl
type: knowledge_article
category: کارشناسی مستقل و پیشگیری از اختلاف
summary: کارشناس باید مرز تحلیل صنعتی، تفسیر حقوقی و شهادت کارشناسی را روشن نگه دارد.
author: علی‌اکبر مرزبان
course_reference: E03
status: editorial-draft
last_editorial_update: '2026-10-25'
original_persian_date: null
canonical_url: https://aliakbarmarzban.ir/fa/knowledge/independent-maritime-expert/
old_url: null
related_service: https://aliakbarmarzban.ir/fa/services/
sources:
- title: BIMCO — Contractual Affairs
  url: https://www.bimco.org/contractual-affairs/
- title: UNCITRAL — Arbitration and Conciliation Resources
  url: https://uncitral.un.org/en/texts/arbitration
- title: World Bank — Port Reform Toolkit (3rd Edition)
  url: https://www.worldbank.org/en/topic/transport/publication/port-reform-toolkit
---

# گزارش کارشناسی مستقل در اختلافات دریایی؛ از ادعا تا شواهد قابل بازبینی

## استقلال پیش از تخصص
در پرونده‌های اختلاف بندری یا کشتیرانی، گزارش فنی و مدیریتی زمانی ارزش دارد که دامنه مأموریت و احتمال تعارض منافع از ابتدا روشن باشد. کارشناس باید اعلام کند برای کدام مسائل نظر می‌دهد، چه اطلاعاتی را بررسی کرده و کدام پرسش خارج از صلاحیت اوست. تحلیل مستقل نباید به بازنویسی موضع یکی از طرفین تبدیل شود.

## ساختار قابل دفاع گزارش
گزارش بهتر است با «مسائل مورد سؤال» آغاز شود و سپس مستندات، خط زمانی، روش تحلیل، فرض‌ها، محدودیت‌ها و نتیجه هر مسئله را تفکیک کند. هر نتیجه باید به سند قابل شناسایی ارجاع داشته باشد. تفکیک **واقعیت احرازشده** از **ادعای طرفین** و **استنباط کارشناسی** کلید قابلیت بازبینی است.

## جدول اسکات و خط زمانی
برای اختلاف بر سر تأخیر تحویل پایانه، جدول می‌تواند نشان دهد کارفرما چه ادعایی مطرح کرده، پیمانکار چه پاسخی داده، کدام اسناد مؤید هر موضع‌اند و چه داده‌ای هنوز موجود نیست. خط زمانی مکاتبات، اخطارها، تغییرات و رویدادهای عملیاتی از تداخل علیت با هم‌زمانی جلوگیری می‌کند.

## پیشگیری بهتر از اختلاف
بسیاری از اختلافات از نبود تعریف روشن تحویل، تعهد ثبت داده یا فرایند کنترل تغییر آغاز می‌شوند. بازبینی کارشناسی پیش از امضا یا در نخستین نشانه انحراف، می‌تواند نقاط ابهام را مستند و به تصمیم اصلاحی تبدیل کند. اظهارنظر نهایی حقوقی یا نمایندگی در داوری باید توسط متخصص دارای صلاحیت مربوط انجام شود.

## چک‌لیست کاربردی
- [ ] شرح مأموریت و تعارض منافع را بررسی کنید
- [ ] واقعیت، ادعا و تحلیل را جدا بنویسید
- [ ] برای هر نتیجه ارجاع به سند ثبت کنید
- [ ] محدودیت داده و دامنه تخصص را افشا کنید

## پرسش‌های متداول
### آیا گزارش کارشناس صنعتی جای نظر وکیل را می‌گیرد؟

خیر. تحلیل فنی یا حکمرانی مکمل ارزیابی حقوقی پرونده‌محور است، نه جایگزین آن.

## حوزه مرتبط
[مشاوره تخصصی تکمیلی](https://aliakbarmarzban.ir/fa/services/)

> یادداشت تحریریه: این مطلب برای آگاهی و تصمیم‌سازی مدیریتی تهیه شده است. اجرای مقررات تابع نسخه معتبر، وضعیت حقوقی کشور و شرایط واقعی پرونده است.

## منابع
- [BIMCO — Contractual Affairs](https://www.bimco.org/contractual-affairs/)
- [UNCITRAL — Arbitration and Conciliation Resources](https://uncitral.un.org/en/texts/arbitration)
- [World Bank — Port Reform Toolkit (3rd Edition)](https://www.worldbank.org/en/topic/transport/publication/port-reform-toolkit)
