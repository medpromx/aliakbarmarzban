---
title: صدور و شناسایی گواهینامه STCW؛ کنترل اصالت، صلاحیت و کیفیت
slug: stcw-certification-quality
language: fa-IR
dir: rtl
type: knowledge_article
category: دریانوردان و عامل انسانی
summary: از تفاوت CoC و CoP تا نظام بررسی گواهینامه و کنترل کیفیت صدور در سطح دولت پرچم.
author: علی‌اکبر مرزبان
course_reference: C05
status: editorial-draft
last_editorial_update: '2026-10-25'
original_persian_date: null
canonical_url: https://aliakbarmarzban.ir/fa/knowledge/stcw-certification-quality/
old_url: null
related_service: https://aliakbarmarzban.ir/fa/services/seafarers-stcw/
sources:
- title: IMO — STCW Convention 1978, as amended
  url: https://www.imo.org/en/ourwork/humanelement/pages/stcw-convention.aspx
- title: IMO — III Code, Resolution A.1070(28)
  url: https://wwwcdn.imo.org/localresources/en/OurWork/IIIS/Documents/1070.pdf
- title: International Maritime Organization — Training and Certification
  url: https://www.imo.org/en/ourwork/humanelement/pages/trainingcertification-default.aspx
---

# صدور و شناسایی گواهینامه STCW؛ کنترل اصالت، صلاحیت و کیفیت

## نقطه شروع: تعریف درست گواهینامه
**گواهینامه شایستگی (CoC)** و **گواهینامه مهارت (CoP)** کاربردهای متفاوت دارند. اداره دریایی برای هر نوع گواهینامه باید پشتوانه آموزشی، سوابق خدمت، شیوه ارزیابی، مبنای حقوقی و رویه صدور مشخص داشته باشد. سامانه صدور نه‌فقط ابزار اداری، بلکه بخشی از اعتبار بین‌المللی نظام آموزش دریانوردان است.

## مرزبندی صدور و شناسایی
مقرره **I/10** کنوانسیون STCW درباره شناسایی گواهینامه‌های صادرشده توسط دولت‌های دیگر است. شناسایی را نباید با صدور اولیه یا ترجمه ساده یک سند اشتباه گرفت. دولت صاحب پرچم باید مطابق شرایط مقرر اطمینان لازم درباره نظام طرف مقابل را به دست آورد و مدارک شناسایی معتبر صادر کند. همچنین باید به الزامات راستی‌آزمایی اصالت و جلوگیری از سوءاستفاده توجه شود.

## نظام کیفیت چه چیزی را کنترل می‌کند؟
طبق مقرره **I/8**، نظام استانداردهای کیفیت و ارزیابی مستقل اهمیت ویژه دارد. کیفیت فقط به حضور ممیز در کلاس محدود نیست؛ باید نشان دهد فرایند آموزش و سنجش صلاحیت تا صدور، شکایت، تعلیق یا تمدید سند قابل ردیابی است. نمونه‌ای از شاخص‌های مدیریتی، مدت صدور، نرخ خطا، تعداد موارد اصالت‌سنجی ناموفق و بسته‌شدن یافته‌های ارزیابی مستقل است.

## الگوی عملیاتی
یک ماتریس فرایند طراحی کنید: درخواست → بررسی صلاحیت → تطبیق مدارک → ارزیابی → تأیید → صدور → راستی‌آزمایی → نگهداری سوابق. برای هر مرحله حق تصمیم، کنترل دو‌مرحله‌ای در نقاط حساس و مسئولیت پاسخ‌گویی تعریف شود. تغییر مقررات باید هم‌زمان در فرم‌ها، سامانه‌ها و دستورالعمل‌ها اعمال شود.

## چک‌لیست کاربردی
- [ ] تفکیک CoC، CoP و ظهرنویسی شناسایی
- [ ] تعریف کنترل اصالت در همه نقاط حساس
- [ ] مستندسازی ارزیابی مستقل I/8
- [ ] پایش شاخص خطا و تأخیر در صدور

## پرسش‌های متداول
### آیا IMO مستقیماً گواهینامه CoC صادر می‌کند؟

خیر. نظام صدور و شناسایی در صلاحیت دولت‌های ذی‌ربط بر اساس چارچوب کنوانسیون است.

## حوزه مرتبط
[دریانوردان، STCW و عامل انسانی](https://aliakbarmarzban.ir/fa/services/seafarers-stcw/)

> یادداشت تحریریه: این مطلب برای آگاهی و تصمیم‌سازی مدیریتی تهیه شده است. اجرای مقررات تابع نسخه معتبر، وضعیت حقوقی کشور و شرایط واقعی پرونده است.

## منابع
- [IMO — STCW Convention 1978, as amended](https://www.imo.org/en/ourwork/humanelement/pages/stcw-convention.aspx)
- [IMO — III Code, Resolution A.1070(28)](https://wwwcdn.imo.org/localresources/en/OurWork/IIIS/Documents/1070.pdf)
- [International Maritime Organization — Training and Certification](https://www.imo.org/en/ourwork/humanelement/pages/trainingcertification-default.aspx)
