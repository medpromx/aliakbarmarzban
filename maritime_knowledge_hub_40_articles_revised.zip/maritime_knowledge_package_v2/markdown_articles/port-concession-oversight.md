---
title: نظارت بر قراردادهای امتیاز بندری؛ از تعهد سرمایه‌گذاری تا کیفیت خدمت
slug: port-concession-oversight
language: fa-IR
dir: rtl
type: knowledge_article
category: حکمرانی بندری و اصلاحات نهادی
summary: قرارداد امتیاز بدون نظام پایش، شفافیت اطلاعات و سازوکار اقدام اصلاحی، ابزار مؤثر حکمرانی نیست.
author: علی‌اکبر مرزبان
course_reference: C03
status: editorial-draft
last_editorial_update: '2026-10-25'
original_persian_date: null
canonical_url: https://aliakbarmarzban.ir/fa/knowledge/port-concession-oversight/
old_url: null
related_service: https://aliakbarmarzban.ir/fa/services/port-governance/
sources:
- title: World Bank — Port Reform Toolkit (3rd Edition)
  url: https://www.worldbank.org/en/topic/transport/publication/port-reform-toolkit
- title: World Bank — Public-Private Partnership Reference and Guidance
  url: https://ppp.worldbank.org/
- title: UNCTAD — Review of Maritime Transport 2025
  url: https://unctad.org/publication/review-maritime-transport-2025
---

# نظارت بر قراردادهای امتیاز بندری؛ از تعهد سرمایه‌گذاری تا کیفیت خدمت

## چرا امضا کافی نیست؟
واگذاری بهره‌برداری پایانه، مسئولیت مرجع عمومی در حفاظت از منافع کاربران و کنترل کیفیت خدمت را حذف نمی‌کند. قرارداد باید در طول عمر چندساله خود مدیریت شود: تعهد سرمایه‌گذاری، نگهداری دارایی، سطح خدمت، تعرفه، دسترسی منصفانه، گزارش‌دهی و انتقال دارایی در پایان دوره همگی به نظارت نیاز دارند.

## شاخص قابل اجرا چگونه نوشته می‌شود؟
عبارت «بهره‌بردار باید کیفیت خدمت مناسب ارائه دهد» معیار مناسبی برای اعمال ضمانت اجرا نیست. شاخص باید تعریف کمّی، دوره سنجش، استثناهای مجاز، روش دسترسی به داده و پیامد نقض داشته باشد. برای مثال هدف بهره‌وری اسکله باید با ترکیب بار، در دسترس‌بودن تجهیزات و شرایط فورس‌ماژور سنجیده شود.

## بازنگری قرارداد و تغییر شرایط
قراردادهای بلندمدت در معرض تغییر تقاضا، فناوری و سیاست محیط‌زیست قرار می‌گیرند. وجود سازوکار تغییر، بازنگری تعرفه و رسیدگی به اختلاف، به اندازه تعریف تعهد اولیه اهمیت دارد. انعطاف‌پذیری لازم نباید به اختیار بی‌ضابطه یک طرف برای تغییر شرایط بدل شود؛ ثبت استدلال و تصویب در مرجع ذی‌صلاح ضروری است.

## بسته پایش پیشنهادشده
یک «دفتر تعهدات امتیاز» همراه با تقویم رویدادهای قراردادی، داشبورد KPI، پرونده انحرافات و سازوکار تشدید ایجاد کنید. لازم است وظایف تیم قرارداد، عملیات، حقوقی و مالی از ابتدا تعیین شود. تصمیم‌های مهم باید مستند و قابل بازبینی باقی بمانند.

## چک‌لیست کاربردی
- [ ] تعهدات سرمایه‌گذاری و نگهداری را زمان‌بندی کنید
- [ ] KPI با تعریف و روش محاسبه قراردادی بنویسید
- [ ] تغییرات و معافیت‌ها را در دفتر تصمیمات ثبت کنید
- [ ] برای انحراف‌ها مسیر اخطار و اصلاح تعریف کنید

## پرسش‌های متداول
### آیا قرارداد امتیاز نظارت عمومی را حذف می‌کند؟

خیر. حدود دقیق نظارت تابع قانون و قرارداد است، اما واگذاری اجرا معمولاً با حذف مسئولیت‌های حاکمیتی همراه نیست.

## حوزه مرتبط
[حکمرانی بندری و اصلاحات نهادی](https://aliakbarmarzban.ir/fa/services/port-governance/)

> یادداشت تحریریه: این مطلب برای آگاهی و تصمیم‌سازی مدیریتی تهیه شده است. اجرای مقررات تابع نسخه معتبر، وضعیت حقوقی کشور و شرایط واقعی پرونده است.

## منابع
- [World Bank — Port Reform Toolkit (3rd Edition)](https://www.worldbank.org/en/topic/transport/publication/port-reform-toolkit)
- [World Bank — Public-Private Partnership Reference and Guidance](https://ppp.worldbank.org/)
- [UNCTAD — Review of Maritime Transport 2025](https://unctad.org/publication/review-maritime-transport-2025)
