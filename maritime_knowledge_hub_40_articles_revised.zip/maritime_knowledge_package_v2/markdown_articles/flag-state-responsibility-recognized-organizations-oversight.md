---
title: واگذاری وظایف به سازمان‌های شناخته‌شده؛ مسئولیت دولت کجا باقی می‌ماند؟
slug: flag-state-responsibility-recognized-organizations-oversight
language: fa-IR
dir: rtl
type: knowledge_article
category: مقررات IMO و انطباق
summary: تفویض صلاحیت‌های بازرسی و صدور گواهینامه‌های قانونی به سازمان‌های شناخته‌شده (ROs) هرگز رافع یا منتقل‌کننده مسئولیت
  حاکمیتی دولت صاحب پرچم نیست؛ بلکه مبنای یک نظام نظارتی الزام‌آور، مستمر و پاسخ‌گو تحت حقوق بین‌الملل است.
author: علی‌اکبر مرزبان
course_reference: C02
status: editorial-draft
last_editorial_update: '2026-10-25'
original_persian_date: null
canonical_url: https://aliakbarmarzban.ir/fa/knowledge/flag-state-responsibility-recognized-organizations-oversight/
old_url: null
related_service: https://aliakbarmarzban.ir/fa/services/imo-regulation/
sources:
- title: International Maritime Organization — Code for Recognized Organizations (RO Code), Resolution MEPC.237(65)
  url: https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MEPCDocuments/MEPC.237%2865%29.pdf
- title: IMO — III Code, Resolution A.1070(28)
  url: https://wwwcdn.imo.org/localresources/en/OurWork/IIIS/Documents/1070.pdf
- title: UN — United Nations Convention on the Law of the Sea
  url: https://www.un.org/depts/los/convention_agreements/texts/unclos/UNCLOS-TOC.htm
---

# واگذاری وظایف به سازمان‌های شناخته‌شده؛ مسئولیت دولت کجا باقی می‌ماند؟

در مدیریت دریانوردی معاصر، اتکای مراجع دریایی به مؤسسات رده‌بندی برای اجرای وظایف فنی امری رایج است. با این حال، تکیه صرف بر این نهادها بدون استقرار چتر نظارتی مستقل، آسیب‌پذیری حقوقی و حاکمیتی سنگینی برای پرچم به همراه دارد.

## ۱. مرز حقوقی میان «تفویض وظیفه فنی» و «مسئولیت غایی حاکمیت»

بر اساس ماده ۹۴ کنوانسیون حقوق دریاها (UNCLOS) و بخش دوم آیین‌نامه اجرای اسناد ایمو (III Code)، اعمال صلاحیت و کنترل مؤثر در امور فنی، اداری و اجتماعی بر شناورها، تکلیف انحصاری دولت صاحب پرچم است. معاهدات بین‌المللی—از جمله مقرره XI-1/1 کنوانسیون سولاس، ضمائم مارپول و مقرره ۵.۱.۱ کنوانسیون کار دریایی (MLC 2006)—به دولت‌ها اجازه می‌دهند ممیزی و صدور اسناد قانونی را به «سازمان‌های شناخته‌شده» (Recognized Organizations - ROs) واگذار نمایند. با این وجود، این اسناد تصریح می‌کنند که تفویض وظایف اجرایی به معنای تفویض مسئولیت نبوده و دولت پرچم همواره پاسخ‌گوی نهایی ایمنی و انطباق ناوگان خود باقی می‌ماند.

## ۲. ارکان نظارت نهادی بر پایه آیین‌نامه RO Code

بر مبنای مقررات «آیین‌نامه سازمان‌های شناخته‌شده» (RO Code موضوع قطعنامه‌های MSC.349(92) و MEPC.237(65)) و بندهای ۱۸ تا ۲۰ کد III، واگذاری وظایف نیازمند یک چارچوب حاکمیتی فعال است:

- **موافقت‌نامه تفویض کتبی:** تنظیم قراردادی رسمی با تعیین دقیق دامنه اختیارات، الزامات گزارش‌دهی و دستورالعمل‌های فنی ملی.
- **برنامه نظارت مدون (Oversight Programme):** اجرای بازرسی‌های تکمیلی سرزده بر روی شناورها و انجام ممیزی‌های دوره‌ای از دفاتر محلی RO.
- **پایش داده‌محور عملکرد:** رصد مستمر نرخ توقیف ناوگان در بازرسی‌های کنترل دولت بندر (PSC) و شناسایی نواقص منتسب به عملکرد سازمان رده‌بندی.

## سه پرسش کاربردی مدیریتی برای رهبران دریایی

پیش از پذیرش گواهینامه‌های صادره، مدیران ارشد حاکمیت دریایی باید این سه پرسش کلیدی را پاسخ دهند:

۱. **آیا موافقت‌نامه رسمی با هر RO، حدود شفاف اختیارات، الزامات گزارش فوری نواقص و تبعیت از تفاسیر ملی را پوشش می‌دهد؟**  
۲. **آیا اداره دریایی از پرسنل متخصص و منابع کافی برای بازرسی‌های تکمیلی و ممیزی مستقیم عملکرد RO برخوردار است؟**  
۳. **چه مکانیزمی برای تحلیل کارنامه عملکرد ROs در گزارش‌های سالانه PSC و اعمال اقدامات اصلاحی مستقر شده است؟**

## بند پایانی و چشم‌انداز اجرایی

واگذاری اختیارات به ROs ابزاری برای جبران محدودیت‌های اداری است، نه راهکاری برای گریز از مسئولیت. در ارزیابی‌های طرح ممیزی کشورهای عضو ایمو (IMSAS)، هرگونه کوتاهی سازمان شناخته‌شده مستقیماً به عنوان قصور دولت پرچم ثبت می‌شود. کارآمدی واقعی زمانی تضمین می‌گردد که صلاحیت فنی با نظارت حاکمیتی فعال پیوند یابد.

## چک‌لیست کاربردی
- [ ] تعیین حدود تفویض اختیار در موافقت‌نامه رسمی با RO
- [ ] بازبینی برنامه ممیزی و نظارت مستقل اداره دریایی
- [ ] تحلیل یافته‌های PSC و عملکرد سازمان‌های شناخته‌شده
- [ ] تعریف اقدامات اصلاحی و سازوکار پاسخ‌گویی دولت پرچم

## حوزه مرتبط
[مقررات بین‌المللی دریایی و امور IMO](https://aliakbarmarzban.ir/fa/services/imo-regulation/)

> یادداشت تحریریه: این مطلب برای آگاهی و تصمیم‌سازی مدیریتی تهیه شده است. اجرای مقررات تابع نسخه معتبر، وضعیت حقوقی کشور و شرایط واقعی پرونده است.

## منابع
- [International Maritime Organization — Code for Recognized Organizations (RO Code), Resolution MEPC.237(65)](https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MEPCDocuments/MEPC.237%2865%29.pdf)
- [IMO — III Code, Resolution A.1070(28)](https://wwwcdn.imo.org/localresources/en/OurWork/IIIS/Documents/1070.pdf)
- [UN — United Nations Convention on the Law of the Sea](https://www.un.org/depts/los/convention_agreements/texts/unclos/UNCLOS-TOC.htm)
