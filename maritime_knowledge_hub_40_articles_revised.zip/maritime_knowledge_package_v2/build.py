from pathlib import Path
from article_data import ARTICLES
from markdown_it import MarkdownIt
from bs4 import BeautifulSoup
from PIL import Image
import html, json, csv, re, sys, shutil, zipfile, yaml, unicodedata

BASE=Path('/mnt/data')
OUT=BASE/'maritime_knowledge_package_v2'
SITE=OUT/'site'
ASSETS=SITE/'assets'
MD=OUT/'markdown_articles'
for p in (SITE,ASSETS,MD): p.mkdir(parents=True,exist_ok=True)

# The integrated navigation uses the ten established taxonomy categories.
CATEGORY_MERGES={'قراردادها و تدارکات دریایی': 'قراردادها و مدیریت ریسک', 'آموزش دریایی و تضمین کیفیت': 'آموزش و توسعه شایستگی', 'سرمایه\u200cگذاری بندری و PPP': 'سرمایه\u200cگذاری و PPP', 'کربن\u200cزدایی دریایی': 'کربن\u200cزدایی و مقررات اقلیمی', 'دیجیتالی\u200cسازی و پنجره واحد': 'دیجیتالی\u200cسازی دریایی', 'کارشناسی و پیشگیری از اختلاف': 'کارشناسی مستقل و پیشگیری از اختلاف'}
for a in ARTICLES:
 a["category"]=CATEGORY_MERGES.get(a["category"],a["category"])

# Add a second directly relevant source to seven previously single-source articles.
EXTRA_REFERENCE_KEYS={
 'port-ppp-bankability':['PPP','UNCTAD'],
 'independent-maritime-expert':['UNCITRAL','PORT'],
 'maritime-training-assurance':['IMOEDU','BIGGS'],
 'stcw-certification-quality':['III','IMOEDU'],
 'maritime-mou-cooperation':['TREATY','IMOSTRUCT'],
 'port-concession-oversight':['PPP','UNCTAD'],
 'maritime-negotiation-brief':['TREATY','UNCTAD']
}
for a in ARTICLES:
 a['sources']=list(dict.fromkeys(a['sources']+EXTRA_REFERENCE_KEYS.get(a['slug'],[])))

# Regulatory fact checks as of 2026-10-25. The uploaded curricula predate a few new resolutions.
for a in ARTICLES:
 if a['slug']=='port-state-control':
  a['body']=a['body'].replace('قطعنامه **A.1185(33)**','قطعنامه جاری **A.1206(34)** (رویه‌های کنترل دولت صاحب بندر، ۲۰۲۵)')
 if a['slug']=='imsas-audit-preparation':
  a['body']=a['body'].replace('بنابراین نظام پایش باید به تحولات رویه‌های ممیزی نیز توجه داشته باشد.', 'چارچوب و رویه‌های بازنگری‌شده **A.1211(34)** از ۳۰ ژوئن ۲۰۲۶ جایگزین سند پیشین شده و چرخه دوم برای ژوئیه ۲۰۲۷ برنامه‌ریزی شده است. سازوکار **پایش مستمر IMSAS (ICMM)** نیز بخشی از جهت‌گیری جدید است.')

SOURCES={
 'III':('IMO — III Code, Resolution A.1070(28)','https://wwwcdn.imo.org/localresources/en/OurWork/IIIS/Documents/1070.pdf'),
 'IMSAS':('IMO — Member State Audit Scheme / A.1211(34)','https://www.imo.org/en/ourwork/msas/pages/default.aspx'),
 'PORT':('World Bank — Port Reform Toolkit (3rd Edition)','https://www.worldbank.org/en/topic/transport/publication/port-reform-toolkit'),
 'UNCTAD':('UNCTAD — Review of Maritime Transport 2025','https://unctad.org/publication/review-maritime-transport-2025'),
 'STCW':('IMO — STCW Convention 1978, as amended','https://www.imo.org/en/ourwork/humanelement/pages/stcw-convention.aspx'),
 'STCWREVIEW':('IMO — Comprehensive review of STCW: FAQ and timeline','https://www.imo.org/en/mediacentre/hottopics/pages/comprehensive-review-of-the-stcw-convention-and-code-faq.aspx'),
 'IMOCONV':('IMO — List of Conventions','https://www.imo.org/en/about/conventions/pages/default.aspx'),
 'UNCLOS':('UN — United Nations Convention on the Law of the Sea','https://www.un.org/depts/los/convention_agreements/texts/unclos/UNCLOS-TOC.htm'),
 'IMOSTRUCT':('IMO — Organization Structure','https://www.imo.org/en/about/pages/structure.aspx'),
 'ILO':('ILO — Maritime Labour Convention, 2006','https://www.ilo.org/international-labour-standards/maritime-labour-convention-2006'),
 'MLC2026':('ILO — MLC amendments and current entry-into-force dates','https://www.ilo.org/global/standards/maritime-labour-convention/text/lang--en/index.htm'),
 'GHG':('IMO — 2023 GHG Strategy (MEPC.377(80))','https://www.imo.org/en/ourwork/environment/pages/2023-imo-strategy-on-reduction-of-ghg-emissions-from-ships.aspx'),
 'NETZERO':('IMO — Net-Zero Framework FAQ','https://www.imo.org/en/mediacentre/hottopics/pages/faqs-the-imo-net-zero-framework.aspx'),
 'MEPC84':('IMO — MEPC 84 outcomes, 2026','https://www.imo.org/en/mediacentre/meetingsummaries/pages/temporary-mepc-84th-session.aspx'),
 'MSW':('IMO — Maritime Single Window','https://www.imo.org/en/ourwork/facilitation/pages/maritimesinglewindow-default.aspx'),
 'FAL':('IMO — FAL Convention and 2022 amendments','https://www.imo.org/en/about/conventions/pages/convention-on-facilitation-of-international-maritime-traffic-%28fal%29.aspx'),
 'PSC':('IMO — Port State Control / A.1206(34)','https://www.imo.org/en/ourwork/iiis/pages/port%20state%20control.aspx'),
 'BIMCO':('BIMCO — Contractual Affairs','https://www.bimco.org/contractual-affairs/'),
 'EUETS':('European Commission — EU ETS Maritime FAQ','https://climate.ec.europa.eu/areas-action/transport-decarbonisation/reducing-emissions-shipping-sector/faq-maritime-transport-eu-emissions-trading-system-ets_en'),
 'FUELEU':('European Commission — FuelEU Maritime','https://transport.ec.europa.eu/transport-modes/maritime/decarbonising-maritime-transport-fueleu-maritime_en')
}
SOURCES.update({'VCLT': ('United Nations — Vienna Convention on the Law of Treaties (1969), Articles 11–16 and 26', 'https://legal.un.org/ilc/texts/instruments/english/conventions/1_1_1969.pdf'), 'ROCODE': ('International Maritime Organization — Code for Recognized Organizations (RO Code), Resolution MEPC.237(65)', 'https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MEPCDocuments/MEPC.237%2865%29.pdf'), 'PSC2025': ('International Maritime Organization — Procedures for Port State Control, 2025, Resolution A.1206(34)', 'https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/AssemblyDocuments/A.1206%2834%29.pdf'), 'ISM': ('International Maritime Organization — International Safety Management (ISM) Code', 'https://www.imo.org/en/ourwork/humanelement/pages/ismcode.aspx'), 'PROCUREMENT': ('World Bank — Procurement Framework for Investment Project Financing', 'https://www.worldbank.org/en/projects-operations/products-and-services/brief/procurement-new-framework'), 'UNCITRALPROC': ('UNCITRAL — Model Law on Public Procurement (2011)', 'https://uncitral.un.org/en/texts/procurement/modellaw/public_procurement'), 'PPP': ('World Bank — Public-Private Partnership Reference and Guidance', 'https://ppp.worldbank.org/'), 'IMOEDU': ('International Maritime Organization — Training and Certification', 'https://www.imo.org/en/ourwork/humanelement/pages/trainingcertification-default.aspx'), 'FATIGUE': ('International Maritime Organization — Guidelines on Fatigue, MSC.1/Circ.1598', 'https://www.imo.org/en/ourwork/humanelement/pages/fatigue.aspx'), 'TREATY': ('United Nations — Treaty Handbook', 'https://treaties.un.org/pages/Resource.aspx?path=Publication/TH/Page1_en.xml'), 'BIGGS': ('Biggs, J., & Tang, C. — Teaching for Quality Learning at University', 'https://www.mheducation.co.uk/teaching-for-quality-learning-at-university-5e-9780335248933-emea-group'), 'KIRKPATRICK': ('Kirkpatrick Partners — The Kirkpatrick Model', 'https://www.kirkpatrickpartners.com/the-kirkpatrick-model/'), 'FALGUIDE': ('International Maritime Organization — FAL Related Guidance and Maritime Single Window Guidelines', 'https://www.imo.org/en/ourwork/facilitation/pages/falguidance-default.aspx'), 'UNCITRAL': ('UNCITRAL — Arbitration and Conciliation Resources', 'https://uncitral.un.org/en/texts/arbitration')})

SERVICES={
'imo-regulation':('مقررات بین‌المللی دریایی و امور IMO','https://aliakbarmarzban.ir/fa/services/imo-regulation/'),
'port-governance':('حکمرانی بندری و اصلاحات نهادی','https://aliakbarmarzban.ir/fa/services/port-governance/'),
'seafarers-stcw':('دریانوردان، STCW و عامل انسانی','https://aliakbarmarzban.ir/fa/services/seafarers-stcw/'),
'maritime-contracts':('قراردادها و تدارکات دریایی','https://aliakbarmarzban.ir/fa/services/maritime-contracts/'),
'international-relations':('مذاکرات و همکاری‌های بین‌المللی','https://aliakbarmarzban.ir/fa/services/international-relations/'),
'executive-training':('آموزش مدیران و ظرفیت‌سازی','https://aliakbarmarzban.ir/fa/services/executive-training/'),
'specialist-advisory':('مشاوره تخصصی تکمیلی','https://aliakbarmarzban.ir/fa/services/specialist-advisory/')
}
# Resolve actual site service slugs for ones not user-supplied: avoid fabricating links; link to service directory instead.
SERVICES['maritime-contracts']=(SERVICES['maritime-contracts'][0],'https://aliakbarmarzban.ir/fa/services/')
SERVICES['international-relations']=(SERVICES['international-relations'][0],'https://aliakbarmarzban.ir/fa/services/')
SERVICES['executive-training']=(SERVICES['executive-training'][0],'https://aliakbarmarzban.ir/fa/services/')
SERVICES['specialist-advisory']=(SERVICES['specialist-advisory'][0],'https://aliakbarmarzban.ir/fa/services/')

# Reuse project-supplied infographics in responsive, optimized image format.
for filename in set(a['image'] for a in ARTICLES):
 src=BASE/filename
 if not src.exists(): raise FileNotFoundError(src)
 im=Image.open(src).convert('RGB'); im.thumbnail((1050,1050))
 im.save(ASSETS/filename.replace('.png','.webp'),'WEBP',quality=78,method=5)

def e(s): return html.escape(str(s),quote=True)
def link_article(a,from_post=False):
 return f'../{a["slug"]}/' if from_post else f'{a["slug"]}/'

def plain_md(s):
 return re.sub(r'[*_`#]','',s)

def render_md_with_toc(mdtext):
 render=MarkdownIt('commonmark',{'html':False,'linkify':True}).enable('table').render(mdtext)
 soup=BeautifulSoup(render,'html.parser'); toc=[]
 for i,h in enumerate(soup.select('h2'),1):
  h['id']=f'section-{i}';toc.append((h['id'],h.get_text(' ',strip=True)))
 return str(soup),toc

CSS=r'''@import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800&display=swap');
:root{--ink:#10263b;--ocean:#0b3149;--night:#081e2f;--teal:#187b84;--mint:#dff2ef;--gold:#e9bb73;--surface:#ffffff;--paper:#f6f8f8;--line:#dce5e8;--secondary:#617384;--max:1220px;color-scheme:light}*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--paper);font:16px/2 'Vazirmatn',Tahoma,Arial,sans-serif;color:var(--ink);direction:rtl;text-align:right}a{color:inherit;text-decoration:none}a:hover{color:var(--teal)}button,input{font:inherit}button{cursor:pointer}img{max-width:100%;display:block}p{margin:0 0 1.1em}h1,h2,h3{line-height:1.55;letter-spacing:-.02em}h1{font-size:clamp(2rem,4.2vw,3.65rem);margin:.2em 0 .4em}h2{font-size:1.6rem;margin:0 0 1rem}h3{font-size:1.16rem;margin:.8rem 0}.container{width:min(calc(100% - 44px),var(--max));margin:auto}.site-header{background:#fff;border-bottom:1px solid var(--line);position:sticky;top:0;z-index:30;box-shadow:0 2px 14px #081f2d08}.nav{height:76px;display:flex;align-items:center;justify-content:space-between;gap:24px}.brand{display:flex;gap:12px;align-items:center;white-space:nowrap;font-weight:800}.logo{height:42px;width:42px;background:var(--ocean);color:#fff;border-radius:13px;display:grid;place-items:center;font-size:23px}.brand small{display:block;font-size:11px;font-weight:400;color:var(--secondary);line-height:1.7}.navlinks{display:flex;gap:28px;align-items:center;font-size:13px;color:#3b5365}.navlinks a[aria-current]{color:var(--teal);font-weight:800}.header-cta,.btn{display:inline-flex;justify-content:center;align-items:center;gap:7px;background:var(--teal);color:#fff;padding:10px 17px;border-radius:11px;font-weight:700;border:0;font-size:13px}.header-cta:hover,.btn:hover{color:#fff;background:#0f616b}.mobile-menu{display:none}.hero{background:linear-gradient(115deg,#08293f,#12394e 70%,#124652);color:#fff;position:relative;overflow:hidden}.hero::before{content:'';position:absolute;width:510px;height:510px;border:1px solid #ffffff1c;border-radius:100%;left:-130px;top:-270px;box-shadow:0 0 0 90px #ffffff08,0 0 0 180px #ffffff04;pointer-events:none}.hero-content{position:relative;display:grid;grid-template-columns:1fr 330px;gap:65px;align-items:center;min-height:365px;padding:64px 0}.eyebrow{font-size:13px;color:var(--gold);font-weight:700;letter-spacing:.01em}.hero h1{max-width:730px}.hero p{color:#dfebee;max-width:700px;font-size:17px}.hero-plate{border:1px solid #ffffff35;background:#ffffff0e;backdrop-filter:blur(4px);padding:25px;border-radius:24px;position:relative}.hero-plate b{font-size:44px;line-height:1.2;display:block;color:var(--gold)}.hero-plate span{font-size:12px;color:#deeff1}.stat-line{height:1px;background:#ffffff35;margin:15px 0}.crumb{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:12px;color:#a9b9c3;margin-bottom:12px}.crumb a:hover{color:#fff}.section{padding:50px 0}.section-head{display:flex;justify-content:space-between;align-items:end;margin-bottom:22px;gap:18px}.section-head p{color:var(--secondary);font-size:14px}.section-head h2{margin:0 0 3px}.filters{border:1px solid var(--line);border-radius:20px;padding:19px;background:#fff;margin-bottom:28px;box-shadow:0 4px 30px #0f2c3a08}.search{display:flex;align-items:center;gap:10px;border:1px solid var(--line);border-radius:12px;padding:0 14px;background:#f9fbfb}.search input{border:0;background:transparent;outline:0;width:100%;padding:13px 3px;color:var(--ink)}.search span{font-size:18px;color:var(--teal)}.categories{display:flex;flex-wrap:wrap;gap:8px;margin-top:14px}.chip{border:1px solid #d7e5e7;background:white;color:#4b6674;border-radius:9px;padding:6px 11px;font-size:12px}.chip.is-active{background:var(--ocean);color:#fff;border-color:var(--ocean)}.result-label{font-size:13px;color:var(--secondary)}.cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:21px}.post-card{border:1px solid var(--line);border-radius:18px;overflow:hidden;background:#fff;display:flex;flex-direction:column;box-shadow:0 4px 12px #20374807;transition:transform .2s,box-shadow .2s}.post-card:hover{transform:translateY(-4px);box-shadow:0 13px 30px #20374812}.card-image{height:182px;object-fit:cover;width:100%;background:#e8f0f1;object-position:top}.card-body{padding:22px;display:flex;flex-direction:column;flex:1}.meta{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:11px;font-weight:700;color:var(--teal)}.meta .dot{color:#a5b0bb}.card-body h3{font-size:18px;line-height:1.7;margin:11px 0 8px}.card-body p{color:var(--secondary);font-size:13px;line-height:1.9}.card-footer{display:flex;align-items:center;justify-content:space-between;border-top:1px solid #edf0f2;margin-top:auto;padding-top:14px;color:var(--teal);font-size:12px;font-weight:700}.showcase{display:grid;grid-template-columns:1.2fr .8fr;gap:30px;align-items:center;background:#e5efee;border-radius:23px;overflow:hidden}.showcase .copy{padding:35px 40px}.showcase p{color:#526c74}.showcase img{height:350px;width:100%;object-fit:cover;object-position:top}.footer{background:var(--night);color:#d7e7eb;padding:38px 0;margin-top:60px;font-size:13px}.footer-inner{display:flex;justify-content:space-between;gap:40px}.footer a{color:#d7e7eb}.footer .small{color:#9db5c3;margin-top:9px}.article-top{background:linear-gradient(120deg,#082f46,#164457);color:white;padding:37px 0 60px}.article-top h1{font-size:clamp(2rem,3.6vw,3.1rem);max-width:900px}.article-top .lead{max-width:830px;color:#d6e8ee;font-size:17px}.article-layout{display:grid;grid-template-columns:minmax(0,1fr) 270px;gap:48px;align-items:start;margin-top:-24px}.article-paper{background:white;border-radius:21px;padding:clamp(23px,4vw,48px);box-shadow:0 12px 40px #10293b10;min-width:0}.article-aside{position:sticky;top:104px;min-width:0}.aside-card{border:1px solid var(--line);background:#fff;border-radius:16px;padding:23px;margin-bottom:17px}.aside-card h3{margin:0 0 9px}.toc{margin:0;padding-right:16px;color:#5c7580;font-size:12px}.toc a{display:block;padding:5px 0}.article-body{font-size:16px;line-height:2.2}.article-body h2{font-size:24px;scroll-margin-top:105px;margin-top:40px;border-bottom:1px solid var(--line);padding-bottom:12px}.article-body strong{color:#0e5e6a}.article-body ul{padding-right:23px}.article-body p{margin-bottom:1.25em}.article-image{width:100%;max-height:420px;object-fit:contain;background:#edf2f3;border:1px solid var(--line);border-radius:16px;padding:10px}.figure-caption{font-size:12px;color:var(--secondary);margin-top:10px}.box-sub{margin-top:40px;background:#f4f9f8;padding:25px 28px;border-radius:14px;border-right:3px solid #338e94}.box-sub h2{font-size:19px;margin:0 0 12px}.checks{list-style:none;margin:0;padding:0}.checks li{padding:5px 0}.checks li:before{content:'✓';color:var(--teal);font-weight:900;margin-left:12px}.faq-item{border-top:1px solid var(--line);padding:16px 0}.faq-item summary{font-weight:700;cursor:pointer}.faq-item p{font-size:14px;color:var(--secondary);margin-top:9px}.ref-list{font-size:13px;line-height:1.8;padding-right:20px}.ref-list li{margin:8px 0}.ref-list a{text-decoration:underline;text-underline-offset:4px;color:#0a7780}.service-box{background:#0f394d;color:#fff;border-radius:15px;padding:25px;margin-top:28px}.service-box p{color:#d7e5e8;font-size:13px}.service-box a{color:#f8d9a0}.shareline{display:flex;align-items:center;justify-content:space-between;gap:10px;border-bottom:1px solid var(--line);padding:0 0 20px;margin-bottom:22px;color:#728290;font-size:12px}.share{border:1px solid var(--line);background:#fff;border-radius:9px;padding:6px 12px;color:var(--teal)}.related-cards{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.related{background:white;border:1px solid var(--line);border-radius:15px;padding:20px}.related h3{font-size:16px}.notice{font-size:12px;color:#6a7a85;border-top:1px solid var(--line);padding-top:18px;margin-top:25px}.no-results{display:none;background:white;border-radius:13px;padding:28px;color:var(--secondary);text-align:center}.no-results.is-visible{display:block}.small{font-size:12px}.sr-only{position:absolute;width:1px;height:1px;clip:rect(0,0,0,0);white-space:nowrap;overflow:hidden}@media(max-width:960px){.cards{grid-template-columns:repeat(2,minmax(0,1fr))}.article-layout{grid-template-columns:1fr}.article-aside{position:static;display:grid;grid-template-columns:repeat(2,1fr);gap:15px}.hero-content{grid-template-columns:1fr 235px;gap:25px}.navlinks{gap:13px}.showcase{grid-template-columns:1fr 1fr}}@media(max-width:650px){.container{width:min(calc(100% - 28px),var(--max))}.site-header .nav{height:68px}.navlinks{display:none}.mobile-menu{display:block;color:var(--teal);font-weight:700;font-size:12px}.header-cta{display:none}.hero-content{grid-template-columns:1fr;padding:44px 0;min-height:auto}.hero-plate{display:none}.cards{grid-template-columns:1fr}.article-top{padding:28px 0 42px}.article-layout{gap:22px}.article-paper{padding:22px 19px}.article-aside{display:block}.footer-inner{display:block}.showcase{grid-template-columns:1fr}.showcase .copy{padding:28px}.showcase img{height:190px}.section{padding:34px 0}.article-body h2{font-size:21px}}
'''
(ASSETS/'styles.css').write_text(CSS+'\n.post-card[hidden]{display:none!important}\n',encoding='utf8')
JS=r'''(()=>{const q=document.querySelector('#site-search'),btns=[...document.querySelectorAll('[data-category]')],cards=[...document.querySelectorAll('.post-card')],count=document.querySelector('#result-count'),empty=document.querySelector('#no-results');let cat='همه';const norm=s=>(s||'').toLocaleLowerCase('fa').normalize('NFKC').replace(/ي/g,'ی').replace(/ك/g,'ک').replace(/\u200c/g,' ').trim();function refresh(){let shown=0;for(const c of cards){let yes=(cat==='همه'||c.dataset.topic===cat)&&norm(c.dataset.search).includes(norm(q?.value||''));c.hidden=!yes;if(yes)shown++}if(count)count.textContent=shown.toLocaleString('fa-IR')+' مقاله';if(empty)empty.classList.toggle('is-visible',shown===0)}btns.forEach(b=>b.addEventListener('click',()=>{cat=b.dataset.category;btns.forEach(n=>{n.classList.toggle('is-active',n===b);n.setAttribute('aria-pressed',n===b?'true':'false')});refresh()}));q?.addEventListener('input',refresh);refresh();document.querySelectorAll('[data-copy-link]').forEach(b=>b.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(location.href);b.textContent='پیوند کپی شد'}catch(e){prompt('پیوند صفحه:',location.href)}}))})();'''
(ASSETS/'main.js').write_text(JS,encoding='utf8')

NAV='''<header class="site-header"><div class="container nav"><a class="brand" href="https://aliakbarmarzban.ir/fa/"><span class="logo" aria-hidden="true">⚓</span><span>علی‌اکبر مرزبان<small>مشاوره بین‌المللی دریایی</small></span></a><nav class="navlinks" aria-label="ناوبری اصلی"><a href="https://aliakbarmarzban.ir/fa/">خانه</a><a href="https://aliakbarmarzban.ir/fa/services/">خدمات مشاوره</a><a href="__HUB__" aria-current="page">دانشنامه</a><a href="https://aliakbarmarzban.ir/fa/training/">آموزش و سخنرانی</a></nav><a class="header-cta" href="https://aliakbarmarzban.ir/fa/consultation/">درخواست مشاوره ↖</a><a class="mobile-menu" href="__HUB__">دانشنامه</a></div></header>'''
FOOTER='''<footer class="footer"><div class="container footer-inner"><div><strong>علی‌اکبر مرزبان · دانشنامه حکمرانی و مقررات دریایی</strong><div class="small">محتوای مرجع برای آگاهی و تصمیم‌سازی؛ جایگزین بررسی حقوقی یا فنی موردی نیست.</div></div><div><a href="https://aliakbarmarzban.ir/fa/">خانه</a> · <a href="https://aliakbarmarzban.ir/fa/services/">خدمات</a> · <a href="__HUB__">دانشنامه</a></div></div></footer>'''

def shell(title,description,body,cssrel,hub,canonical,ld):
 return f'''<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{e(title)} | علی‌اکبر مرزبان</title><meta name="description" content="{e(description)}"><meta name="robots" content="index,follow"><link rel="canonical" href="{e(canonical)}"><link rel="stylesheet" href="{cssrel}styles.css"><meta name="theme-color" content="#0b3149"><meta property="og:type" content="article"><meta property="og:title" content="{e(title)}"><meta property="og:description" content="{e(description)}"><meta property="og:locale" content="fa_IR"><script type="application/ld+json">{json.dumps(ld,ensure_ascii=False).replace('</','<\\/')}</script></head><body>{NAV.replace('__HUB__',hub)}{body}{FOOTER.replace('__HUB__',hub)}<script defer src="{cssrel}main.js"></script></body></html>'''

categories=list(dict.fromkeys(a['category'] for a in ARTICLES))
ALL_URL='https://aliakbarmarzban.ir/fa/knowledge/'

# Build per-article metadata and publication pages.
for a in ARTICLES:
 title=a['title'];slug=a['slug'];url=ALL_URL+slug+'/'
 refs=[SOURCES[k] for k in a['sources']]
 service_title,service_url=SERVICES[a['service']]
 a['reading_minutes']=max(3,round(len(a['body'].split())/170)+1)
 a['url']=url
 a['primary_source']=refs[0][1]
 last='2026-10-25'
 old_date={'iii-code-implementation':'۱۴۰۵-۰۶-۲۴','port-governance-models':'۱۴۰۵-۰۵-۲۹','stcw-review-readiness':'۱۴۰۵-۰۴-۱۹'}.get(slug)
 fm={'title':title,'slug':slug,'language':'fa-IR','dir':'rtl','type':'knowledge_article','category':a['category'],'summary':a['excerpt'],'author':'علی‌اکبر مرزبان','course_reference':a['course'],'status':'revised-existing' if a['old'] else 'editorial-draft','last_editorial_update':last,'original_persian_date':old_date,'canonical_url':url,'old_url':a['old'],'related_service':service_url,'sources':[{'title':t,'url':u} for t,u in refs]}
 markdown='---\n'+yaml.safe_dump(fm,allow_unicode=True,sort_keys=False,width=120)+'---\n\n# '+title+'\n\n'+a['body']+'\n\n## چک‌لیست کاربردی\n'+'\n'.join('- [ ] '+x for x in a['checks'])+'\n'
 if a['faq']: markdown+='\n## پرسش‌های متداول\n'+'\n\n'.join('### '+q+'\n\n'+v for q,v in a['faq'])+'\n'
 markdown+='\n## حوزه مرتبط\n'+'['+service_title+']('+service_url+')\n\n> یادداشت تحریریه: این مطلب برای آگاهی و تصمیم‌سازی مدیریتی تهیه شده است. اجرای مقررات تابع نسخه معتبر، وضعیت حقوقی کشور و شرایط واقعی پرونده است.\n\n## منابع\n'+'\n'.join(f'- [{t}]({u})' for t,u in refs)+'\n'
 (MD/(slug+'.md')).write_text(markdown,encoding='utf8')
 body,toc=render_md_with_toc(a['body'])
 checks=''.join('<li>'+e(s)+'</li>' for s in a['checks'])
 faqs=''.join('<details class="faq-item"><summary>'+e(q)+'</summary><p>'+e(ans)+'</p></details>' for q,ans in a['faq'])
 sources='<ol class="ref-list">'+''.join(f'<li><a target="_blank" rel="noopener noreferrer" href="{e(u)}">{e(t)}</a></li>' for t,u in refs)+'</ol>'
 related=[x for x in ARTICLES if x is not a and x['category']==a['category']][:2]
 if len(related)<2: related.extend(x for x in ARTICLES if x is not a and x not in related and x['course'][:1]==a['course'][:1])
 related=related[:2]
 related_html=''.join(f'<a class="related" href="{link_article(r,True)}"><span class="meta">{e(r["category"])}</span><h3>{e(r["title"])}</h3><p class="small" style="color:#6b7a85">{e(r["excerpt"])}</p></a>' for r in related)
 toc_html=''.join(f'<li><a href="#{id}">{e(t)}</a></li>' for id,t in toc)
 toc_html=''.join(f'<li><a href="# {id}">{e(t)}</a></li>'.replace('# ','#') for id,t in toc)
 detail_faq = f'<section class="faq-section"><h2>پرسش‌های متداول</h2>{faqs}</section>' if a['faq'] else ''
 article_body=f'''<section class="article-top"><div class="container"><nav class="crumb" aria-label="مسیر صفحه"><a href="https://aliakbarmarzban.ir/fa/">خانه</a> ‹ <a href="../">دانشنامه</a> ‹ {e(a['category'])}</nav><div class="eyebrow">دانشنامه تخصصی · {e(a['course'])}</div><h1>{e(title)}</h1><p class="lead">{e(a['excerpt'])}</p><div class="meta" style="color:#deedf0">علی‌اکبر مرزبان <span class="dot">·</span> {a['reading_minutes']} دقیقه مطالعه <span class="dot">·</span> ویرایش: ۲۵ اکتبر ۲۰۲۶</div></div></section><div class="container article-layout"><main class="article-paper"><div class="shareline"><span>دانشنامه / {e(a['category'])}</span><button class="share" type="button" data-copy-link>کپی پیوند مقاله</button></div><figure style="margin:0 0 26px"><img class="article-image" src="../../../assets/{e(a['image'].replace('.png','.webp'))}" alt="تصویر موضوعی {e(a['category'])}" loading="eager"><figcaption class="figure-caption">تصویر موضوعی — برای وضعیت حقوقی و تاریخ اعتبار به اسناد رسمی مراجعه شود.</figcaption></figure><div class="article-body">{body}</div><section class="box-sub"><h2>چک‌لیست اجرایی</h2><ul class="checks">{checks}</ul></section>{detail_faq}<section class="related-service"><h2>حوزه مرتبط</h2><p><a href="{e(service_url)}">{e(service_title)}</a></p></section><p class="notice">این نوشته، محتوای دانشنامه‌ای و مدیریتی است و جایگزین بررسی تخصصی وضعیت حقوقی و فنی هر پرونده نیست.</p><section class="bibliography" aria-label="منابع"><h2>منابع</h2>{sources}</section></main><aside class="article-aside"><div class="aside-card"><h3>فهرست مقاله</h3><ol class="toc">{toc_html}</ol></div><div class="aside-card"><h3>مشخصات مطلب</h3><p class="small">دسته: {e(a['category'])}<br>حوزه آموزشی: {e(a['course'])}<br>مدت مطالعه: {a['reading_minutes']} دقیقه<br>آخرین ویرایش: ۲۵ اکتبر ۲۰۲۶</p><a style="color:#0b7780;font-size:13px;font-weight:700" href="../">← بازگشت به دانشنامه</a></div></aside></div><section class="container section"><div class="section-head"><h2>مطالعه بیشتر</h2></div><div class="related-cards">{related_html}</div></section>'''
 faq_schema=[{'@type':'Question','name':q,'acceptedAnswer':{'@type':'Answer','text':ans}} for q,ans in a['faq']]
 ld={'@context':'https://schema.org','@graph':[{'@type':'Article','headline':title,'description':a['excerpt'],'inLanguage':'fa-IR','author':{'@type':'Person','name':'علی‌اکبر مرزبان'},'dateModified':last,'mainEntityOfPage':url,'publisher':{'@type':'Person','name':'علی‌اکبر مرزبان'}},{'@type':'FAQPage','mainEntity':faq_schema},{'@type':'BreadcrumbList','itemListElement':[{'@type':'ListItem','position':1,'name':'خانه','item':'https://aliakbarmarzban.ir/fa/'},{'@type':'ListItem','position':2,'name':'دانشنامه','item':ALL_URL},{'@type':'ListItem','position':3,'name':title,'item':url}]}]}
 p=SITE/'fa'/'knowledge'/slug/'index.html';p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(shell(title,a['excerpt'],article_body,'../../../assets/','../',url,ld),encoding='utf8')

# Landing hub cards.
featured=next(x for x in ARTICLES if x['slug']=='iii-code-implementation')
cards='\n'.join(f'''<article class="post-card" data-topic="{e(a['category'])}" data-search="{e(a['category']+' '+a['title']+' '+a['excerpt']+' '+a['course'])}"><a href="{link_article(a)}" aria-label="مطالعه {e(a['title'])}"><img class="card-image" loading="lazy" src="../../assets/{e(a['image'].replace('.png','.webp'))}" alt="نمای تصویری موضوع {e(a['category'])}"></a><div class="card-body"><div class="meta"><span>{e(a['category'])}</span><span class="dot">·</span><span>{e(a['course'])}</span></div><a href="{link_article(a)}"><h3>{e(a['title'])}</h3></a><p>{e(a['excerpt'])}</p><a href="{link_article(a)}" class="card-footer"><span>مطالعه راهنما</span><span>{a['reading_minutes']} دقیقه ←</span></a></div></article>''' for a in ARTICLES)
chips=''.join(f'<button class="chip {"is-active" if i==0 else ""}" data-category="{e(c)}" aria-pressed="{"true" if i==0 else "false"}">{e(c)}</button>' for i,c in enumerate(['همه']+categories))
landing=f'''<section class="hero"><div class="container hero-content"><div><nav class="crumb"><a href="https://aliakbarmarzban.ir/fa/">خانه</a> ‹ دانشنامه</nav><div class="eyebrow">MARITIME KNOWLEDGE HUB</div><h1>دانشنامه حکمرانی<br>و مقررات دریایی</h1><p>مرجعی تخصصی برای فهم مقررات بین‌المللی، طراحی حکمرانی بندری و تبدیل دانش به تصمیم اجرایی؛ با مقالات مستند، راهنماهای مدیریتی و منابع اولیه قابل پیگیری.</p></div><div class="hero-plate"><b>{len(ARTICLES):02d}</b><span>راهنمای تخصصی و محتوای مرجع</span><div class="stat-line"></div><b>{len(categories):02d}</b><span>حوزه تخصصی حکمرانی دریایی</span><div class="stat-line"></div><span>برگرفته از معماری ۱۲ دوره و ۵۶ جلسه آموزشی</span></div></div></section><main class="container section"><div class="section-head"><div><div class="eyebrow" style="color:#13838a">یادگیری مستند برای تصمیم‌گیری بهتر</div><h2>کتابخانه تخصصی دانشنامه</h2><p>مقاله‌ها را بر اساس موضوع جست‌وجو یا دسته‌بندی کنید.</p></div><span id="result-count" class="result-label">{len(ARTICLES)} مقاله</span></div><div class="filters"><label class="sr-only" for="site-search">جست‌وجو در دانشنامه</label><div class="search"><span aria-hidden="true">⌕</span><input id="site-search" type="search" placeholder="جست‌وجو در مقررات IMO، STCW، بنادر، قراردادها و ..." autocomplete="off"></div><div class="categories" role="group" aria-label="دسته‌بندی مطالب">{chips}</div></div><div class="cards" id="post-list">{cards}</div><div id="no-results" class="no-results" aria-live="polite">مقاله‌ای با این عبارت و دسته‌بندی پیدا نشد؛ عبارت دیگری امتحان کنید.</div></main><section class="container showcase"><div class="copy"><div class="eyebrow" style="color:#177e83">از دانش تا اقدام</div><h2>منابع برای مطالعه، ابزارها برای تصمیم</h2><p>محتوا از ساختار برنامه تخصصی حکمرانی دریایی استخراج و به قالب مقاله مرجع، چک‌لیست اجرایی و راهنمای مدیریتی بازطراحی شده است.</p><a class="btn" href="https://aliakbarmarzban.ir/fa/services/">مشاهده خدمات مشاوره ↖</a></div><img src="../../assets/IMO_Regulatory_System_Overview.webp" alt="نمودار ساختار نظام مقررات IMO" loading="lazy"></section>'''
ld_hub={'@context':'https://schema.org','@type':'CollectionPage','name':'دانشنامه حکمرانی و مقررات دریایی','inLanguage':'fa-IR','url':ALL_URL,'description':'مرجع تخصصی مقالات و راهنماهای حکمرانی و مقررات بین‌المللی دریایی','hasPart':[{'@type':'Article','name':a['title'],'url':a['url']} for a in ARTICLES]}
p=SITE/'fa'/'knowledge'/'index.html';p.parent.mkdir(parents=True,exist_ok=True)
p.write_text(shell('دانشنامه حکمرانی و مقررات دریایی','مقالات تخصصی و راهنماهای اجرایی IMO، STCW، حکمرانی بندری، MSW، کربن‌زدایی، قراردادها و مدیریت ریسک.',landing,'../../assets/','./',ALL_URL,ld_hub),encoding='utf8')
(SITE/'index.html').write_text('<!doctype html><html lang="fa" dir="rtl"><meta charset="utf-8"><meta http-equiv="refresh" content="0;url=fa/knowledge/"><a href="fa/knowledge/">ورود به پیش‌نمایش دانشنامه</a></html>',encoding='utf8')

# Generic CMS export and migration notes.
with (OUT/'cms_import.csv').open('w',encoding='utf-8-sig',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=['title','slug','category','excerpt','body_markdown','course_reference','seo_description','canonical_url','original_url','last_reviewed','primary_source_url','status']);writer.writeheader()
 for a in ARTICLES: writer.writerow({'title':a['title'],'slug':a['slug'],'category':a['category'],'excerpt':a['excerpt'],'body_markdown':(MD/(a['slug']+'.md')).read_text(encoding='utf8').split('---\n\n',1)[-1],'course_reference':a['course'],'seo_description':a['excerpt'],'canonical_url':a['url'],'original_url':a['old'] or '','last_reviewed':'2026-10-25','primary_source_url':a['primary_source'],'status':'revised-existing' if a['old'] else 'draft'})
manifest=[{k:a[k] for k in ['slug','title','category','excerpt','course','url','reading_minutes','old']} for a in ARTICLES]
(OUT/'content_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf8')
urls=[ALL_URL]+[a['url'] for a in ARTICLES]
xml='<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n'+''.join(f'  <url><loc>{e(u)}</loc><lastmod>2026-10-25</lastmod></url>\n' for u in urls)+'</urlset>'
(SITE/'sitemap-knowledge.xml').write_text(xml,encoding='utf8')
(OUT/'migration-apache-example.htaccess').write_text('''# Apply only after the new knowledge pages are live and tested.
Redirect 301 /fa/insights/ https://aliakbarmarzban.ir/fa/knowledge/
Redirect 301 /fa/insights/iii-code-implementation/ https://aliakbarmarzban.ir/fa/knowledge/iii-code-implementation/
Redirect 301 /fa/insights/port-governance-models/ https://aliakbarmarzban.ir/fa/knowledge/port-governance-models/
Redirect 301 /fa/insights/stcw-review-readiness/ https://aliakbarmarzban.ir/fa/knowledge/stcw-review-readiness/
''',encoding='utf8')
(OUT/'homepage_section_snippet.html').write_text('''<!-- For insertion into the existing home page; adapt to the site's styles -->
<section dir="rtl" aria-labelledby="knowledge-title"><p>دانشنامه حکمرانی و مقررات دریایی</p><h2 id="knowledge-title">از دانش تخصصی تا تصمیم اجرایی</h2><p>راهنماها و مقالات مستند درباره مقررات IMO، حکمرانی بندری، STCW، دیجیتالی‌سازی و کربن‌زدایی دریایی.</p><p><a href="/fa/knowledge/">مشاهده دانشنامه و تمامی راهنماها</a></p><ul><li><a href="/fa/knowledge/iii-code-implementation/">از الحاق تا نتیجه: کد III</a></li><li><a href="/fa/knowledge/port-governance-models/">مدل حکمرانی بندری و پاسخ‌گویی</a></li><li><a href="/fa/knowledge/stcw-review-readiness/">آمادگی بازنگری STCW</a></li></ul></section>''',encoding='utf8')

readme=f'''# بسته بازطراحی «دانشنامه حکمرانی و مقررات دریایی»

- نام نهایی: دانشنامه حکمرانی و مقررات دریایی — Maritime Governance & Regulatory Knowledge Hub
- تعداد مقالات: {len(ARTICLES)} (سه مقاله موجود بازنویسی‌شده + {len(ARTICLES)-3} مقاله جدید)
- تعداد دسته‌های موضوعی: {len(categories)}
- تاریخ بررسی منابع: 2026-10-25
- پایه محتوایی: فایل جامع ۱۲ دوره و ۵۶ جلسه، دوره‌های C01–C08 و E01–E04، سیلابس و یادداشت‌های ارسالی و اینفوگرافیک‌های پروژه.
- راستی‌آزمایی تکمیلی: IMO, ILO, World Bank, UNCTAD, European Commission, BIMCO.

## پیش‌نمایش
فایل `site/index.html` یا `site/fa/knowledge/index.html` را در مرورگر باز کنید. جست‌وجو و فیلتر موضوعی بدون نیاز به سرور عمل می‌کنند. برای میزبانی، کل محتوای پوشه `site` را با ساختار پوشه‌ها منتقل کنید. پوشه assets دارای تصاویر WebP فشرده‌شده از فایل‌های ارسالی شماست.

## انتقال به CMS
هر مقاله Markdown جداگانه با Frontmatter و منابع در `markdown_articles/` وجود دارد. فایل `cms_import.csv` برای انتقال یا مپ‌کردن فیلدها در CMSهای مختلف است؛ فرمت اختصاصی ایمپورتر وردپرس نیست. عنوان، برچسب و متن را در CMS مقصد نگاشت کنید. قبل از انتشار نهایی مقاله‌های جدید، بازبینی ویراستاری، تطبیق حقوقی و انتخاب تاریخ انتشار انجام دهید. انتشار زنده روی دامنه انجام نشده است.

## مهاجرت سئو
نشانی فهرست: `/fa/knowledge/`.
نشانی‌های جدید مقالات: `/fa/knowledge/{{slug}}/`.
پس از استقرار کامل صفحات، برای `/fa/insights/` و سه مقاله قبلی، ریدایرکت ۳۰۱ تنظیم کنید (نمونه در فایل htaccess). پیش از فعال‌کردن ریدایرکت‌ها اطمینان حاصل کنید مقصد کد ۲۰۰ دارد و canonical صفحات جدید درست است. فایل سایت‌مپ مستقل `site/sitemap-knowledge.xml` را با سایت‌مپ اصلی یکپارچه کنید. صفحه‌های قدیمی و جدید را همزمان بدون canonical و redirect مناسب ایندکس نکنید.

## محدودیت‌های مهم
- ۲۳ مقاله و چک‌لیست، معادل انتشار کامل ۵۶ بسته آموزشی نیستند؛ ۵۶ بسته منبع توسعه موضوعی‌اند.
- اصلاحیه‌های احتمالی آینده STCW، IMO Net-Zero و مقررات اتحادیه اروپا باید پیش از انتشار/استناد اجرایی دوباره از منابع رسمی بررسی شوند.
- در نسخه ۲۰۲۶، رویه PSC قطعنامه A.1206(34) و چارچوب جدید IMSAS قطعنامه A.1211(34) مبنا قرار گرفته است، نه نسخه‌های قدیمی‌تر موجود در بعضی فایل‌ها.
- ادعای تأیید رسمی برنامه آموزشی توسط IMO مطرح نشده است.
- پیوندهای منتهی به صفحه کلی خدمات باید در CMS با صفحات خدمت واقعی جایگزین شوند، در صورت وجود.

## ساختار فایل‌ها
- `site/` خروجی آماده پیش‌نمایش HTML/CSS/JS، تصاویر و صفحات مقاله
- `markdown_articles/` متن کامل همه مقالات با فراداده و منابع
- `cms_import.csv` ردیف‌های قابل نگاشت در سیستم مدیریت محتوا
- `content_manifest.json` فهرست ماشینی مقالات
- `homepage_section_snippet.html` قطعه قابل افزودن به خانه
- `migration-apache-example.htaccess` نمونه ریدایرکت‌های مهاجرت
'''
(OUT/'README_FA.md').write_text(readme,encoding='utf8')
for name in ('article_data.py','build.py'):
 shutil.copy2(Path(__file__).parent/name,OUT/('source_'+name))

zfile=BASE/'maritime_knowledge_hub_40_articles_revised.zip'
with zipfile.ZipFile(zfile,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for f in OUT.rglob('*'):
  if f.is_file(): z.write(f,f.relative_to(BASE))
print('BUILT',len(ARTICLES),'articles',len(categories),'categories')
print('Output:',zfile,round(zfile.stat().st_size/1e6,2),'MB')
print('Landing:',SITE/'fa'/'knowledge'/'index.html')
print('Sample:',SITE/'fa'/'knowledge'/'iii-code-implementation'/'index.html')
